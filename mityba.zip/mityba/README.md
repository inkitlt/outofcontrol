# Mitybos planas (PWA)

Mobili mitybos planavimo programėlė lietuvių kalba: kalorijos, meniu, gaminimas, pirkiniai, žurnalas ir ataskaita.

## Kas kur

| Failas | Kam |
|---|---|
| `index.html`, `styles.css`, `app.js` | Pati programėlė (logika perkelta iš `mityba.html` be pakeitimų) |
| `config.js` | Vieši Supabase nustatymai (URL ir publishable raktas) |
| `api/ai.js` | Serverio funkcija Claude užklausoms (`POST /api/ai`) su dienos limitu |
| `supabase/schema.sql` | Duomenų bazės lentelės ir apsauga (RLS) |
| `manifest.webmanifest`, `sw.js`, `icons/` | Įdiegimas į telefoną ir veikimas be interneto |
| `vendor/supabase.js` | Supabase biblioteka (įdėta, kad veiktų be interneto) |

## Vercel aplinkos kintamieji (Settings → Environment Variables)

| Pavadinimas | Reikšmė |
|---|---|
| `SUPABASE_URL` | `https://quxtpkifohrggosllqyr.supabase.co` |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase **secret** (service_role) raktas – slaptas |
| `ANTHROPIC_API_KEY` | Anthropic API raktas – slaptas |
| `AI_DAILY_LIMIT` | nebūtina, numatyta 20 užklausų vienam žmogui per dieną |
| `ANTHROPIC_MODEL` | nebūtina, numatyta `claude-sonnet-5-5` |

## Duomenys

- `user_state` – profilis, meniu, Claude receptai, pasirinktos prekės (viena eilutė žmogui).
- `day_logs` – viena eilutė vienai žurnalo dienai.
- `ai_usage` – Claude užklausų skaičius per dieną.

Kiekvienas mato tik savo duomenis (Row Level Security). Telefone duomenys laikomi ir vietoje, todėl programėlė veikia be interneto, o pakeitimai išsiunčiami atsiradus ryšiui.

## Atnaujinimai

Pakeitus failus, `sw.js` faile padidink `VERSION` (pvz., `mityba-v2`), kad telefonai gautų naują versiją.
