// POST /api/ai – Claude užklausos per serverį. Raktas lieka tik Vercel aplinkos kintamuosiuose.
// Body: { prompt: string, json?: boolean }  ·  Header: Authorization: Bearer <Supabase access token>

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";
const DAILY_LIMIT = parseInt(process.env.AI_DAILY_LIMIT || "20", 10);

// Naujo tipo raktai (sb_secret_…) siunčiami tik „apikey“ antraštėje; seni (JWT) – ir Authorization.
const srvHeaders = () => {
  const h = { apikey: SERVICE_KEY, "Content-Type": "application/json" };
  if (String(SERVICE_KEY).startsWith("eyJ")) h.Authorization = `Bearer ${SERVICE_KEY}`;
  return h;
};

const send = (res, code, obj) => {
  res.statusCode = code;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(obj));
};

const readBody = async (req) => {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") return JSON.parse(req.body || "{}");
  const chunks = [];
  for await (const c of req) chunks.push(c);
  return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
};

const extractJSON = (t) => {
  const s = String(t || "").replace(/```(?:json)?/g, "");
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a < 0 || b <= a) return null;
  try { return JSON.parse(s.slice(a, b + 1)); } catch { return null; }
};

module.exports = async (req, res) => {
  if (req.method !== "POST") return send(res, 405, { code: "method" });
  if (!SUPABASE_URL || !SERVICE_KEY || !ANTHROPIC_KEY) return send(res, 500, { code: "not_configured" });

  // 1. Kas klausia? Patikriname Supabase sesiją.
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return send(res, 401, { code: "auth" });
  const ur = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SERVICE_KEY, Authorization: `Bearer ${token}` },
  });
  if (!ur.ok) return send(res, 401, { code: "auth" });
  const user = await ur.json();
  if (!user || !user.id) return send(res, 401, { code: "auth" });

  let body;
  try { body = await readBody(req); } catch { return send(res, 400, { code: "bad_request" }); }
  const prompt = String(body.prompt || "");
  if (!prompt || prompt.length > 30000) return send(res, 400, { code: "bad_request" });

  // 2. Dienos limitas vienam vartotojui.
  const lr = await fetch(`${SUPABASE_URL}/rest/v1/rpc/ai_take`, {
    method: "POST",
    headers: srvHeaders(),
    body: JSON.stringify({ p_user: user.id, p_limit: DAILY_LIMIT }),
  });
  if (!lr.ok) return send(res, 500, { code: "limit_check" });
  if ((await lr.json()) !== true) return send(res, 429, { code: "daily_limit", limit: DAILY_LIMIT });

  // 3. Claude.
  const system = body.json
    ? "Atsakyk tik vienu galiojančiu JSON objektu, be jokio kito teksto ir be ``` žymų."
    : "Atsakyk lietuviškai.";
  const ar = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": ANTHROPIC_KEY,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({ model: MODEL, max_tokens: 12000, system, messages: [{ role: "user", content: prompt }] }),
  });
  if (ar.status === 429) return send(res, 429, { code: "rate_limited" });
  if (!ar.ok) {
    const t = await ar.text().catch(() => "");
    console.error("Anthropic klaida", ar.status, t.slice(0, 500));
    return send(res, 502, { code: "ai_error", status: ar.status });
  }
  const out = await ar.json();
  const text = (out.content || []).filter((c) => c.type === "text").map((c) => c.text).join("");
  if (body.json) {
    const data = extractJSON(text);
    if (!data) return send(res, 502, { code: "bad" });
    return send(res, 200, { data });
  }
  return send(res, 200, { text });
};
