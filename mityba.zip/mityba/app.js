{
const ALLSLOTS=[
 {k:"B",n:"Pusryčiai",w:"iš vakaro",t:{p:60,c:72,f:10}},
 {k:"L",n:"Pietūs",w:"dėžutė",t:{p:70,c:100,f:14}},
 {k:"S",n:"Užkandis",w:"",t:{p:32,c:5,f:18}},
 {k:"A",n:"Popietė",w:"",t:{p:40,c:35,f:13}},
 {k:"D",n:"Vakarienė",w:"po treniruotės",t:{p:61,c:81,f:13}}
];
let SLOTS=ALLSLOTS;
const MEALSETS={3:["B","L","D"],4:["B","L","A","D"],5:["B","L","S","A","D"]};
const CATS=["Mėsa ir žuvis","Pieno produktai ir kiaušiniai","Kruopos ir makaronai","Skardinės ir padažai","Šaldyti","Daržovės ir vaisiai","Kita"];
const [M,P,K,S,F,V,O]=CATS;
const LIB=[
 {id:"b1",s:"B",n:"Avižinė košė su tirštu jogurtu",d:"80 g avižų, 30 g išrūgų baltymų, 200 g tiršto jogurto (Skyr), 100 g uogų, 10 g chia",p:60,c:72,f:10,
  ing:[["Avižiniai dribsniai",80,"g",K],["Išrūgų baltymų milteliai",30,"g",O],["Liesas tirštas jogurtas (Skyr)",200,"g",P],["Šaldytos uogos",100,"g",F],["Ispaninio šalavijo (chia) sėklos",10,"g",O]],
  prep:["Į stiklainį: dribsniai, baltymai, chia, jogurtą ir ~150 ml vandens ar pieno, išmaišyk.","Ant viršaus uogos. Ruošk 3–4 stiklainius iš karto."]},
 {id:"b2",s:"B",n:"Varškės ir avižų košė su bananu",d:"70 g avižų, 200 g liesos varškės, 25 g baltymų, bananas, 15 g riešutų sviesto",p:70,c:80,f:15,
  ing:[["Avižiniai dribsniai",70,"g",K],["Liesa varškė",200,"g",P],["Išrūgų baltymų milteliai",25,"g",O],["Bananai",1,"vnt",V],["Žemės riešutų sviestas (kremas)",15,"g",O]],
  prep:["Dribsnius, baltymus ir varškę sumaišyk su ~150 ml vandens stiklainyje.","Ryte supjaustyk bananą, uždėk riešutų sviesto."]},
 {id:"b3",s:"B",n:"Orkaitėje keptas avižų blynas",d:"70 g avižų, 2 kiaušiniai, 150 g varškės; valgyk su 150 g tiršto jogurto ir uogomis",p:66,c:64,f:16,
  ing:[["Avižiniai dribsniai",70,"g",K],["Kiaušiniai",2,"vnt",P],["Liesa varškė",150,"g",P],["Liesas tirštas jogurtas (Skyr)",150,"g",P],["Šaldytos uogos",100,"g",F]],
  prep:["Visos savaitės dribsnius, kiaušinius ir varškę sutrink, įberk kepimo miltelių ir cinamono.","Išpilk į 2 skardas su kepimo popieriumi, kepk 180 °C 25–30 min, supjaustyk 7 dalimis.","Pusę užšaldyk. Valgyk šaltą su tirštu jogurtu ir uogomis."]},
 {id:"l1",s:"L",n:"Vištiena su ryžiais ir daržovėmis",d:"250 g vištienos krūtinėlės (žalia), 120 g ryžių (sausi), 200 g daržovių, 10 g aliejaus",p:70,c:106,f:14,
  ing:[["Vištienos krūtinėlė",250,"g",M],["Ryžiai",120,"g",K],["Šaldytas daržovių mišinys",200,"g",F],["Alyvuogių aliejus",10,"ml",O],["Paprika, česnakas, druska",0,"",O]],
  prep:["Vištieną pamarinuok su aliejumi, paprika, česnaku ir druska, kepk orkaitėje 200 °C 22–25 min.","Ryžiai greitpuodyje: 1 dalis ryžių ir 1,25 vandens, 4 min.","Daržoves kepk ant antros skardos 15 min arba troškink keptuvėje."]},
 {id:"l2",s:"L",n:"Kalakutienos kotletai su grikiais",d:"250 g kalakutienos faršo, 110 g grikių (sausi), 200 g daržovių",p:74,c:94,f:19,
  ing:[["Kalakutienos krūtinėlės faršas",250,"g",M],["Grikiai",110,"g",K],["Šaldytas daržovių mišinys",200,"g",F],["Svogūnai",30,"g",V],["Alyvuogių aliejus",10,"ml",O],["Česnakas, prieskoniai",0,"",O]],
  prep:["Faršą sumaišyk su tarkuotu svogūnu, česnaku ir prieskoniais, suformuok kotletus.","Kepk orkaitėje 200 °C 18–20 min arba airfryer 190 °C 12 min.","Grikiai greitpuodyje: 1 dalis grikių ir 2 vandens, 4 min."]},
 {id:"l3",s:"L",n:"Vištienos karis su ryžiais",d:"250 g vištienos, 110 g ryžių (sausi), 80 ml lengvo kokosų pieno, daržovės",p:70,c:98,f:11,
  ing:[["Vištienos krūtinėlė",250,"g",M],["Ryžiai",110,"g",K],["Kokosų pienas (sumažinto riebumo)",80,"ml",S],["Šaldytas daržovių mišinys",150,"g",F],["Svogūnai",30,"g",V],["Kario pasta",0,"",O]],
  prep:["Greitpuodyje apkepink svogūną, sudėk vištienos kubelius, kario pastą, kokosų pieną ir daržoves.","Aukštas slėgis 6 min.","Ryžius virk atskirai: 1 dalis ryžių ir 1,25 vandens, 4 min."]},
 {id:"s1",s:"S",n:"Kiaušinių keksiukai",d:"3 kiaušiniai, 60 g varškės, špinatai, paprika, truputis sūrio",p:32,c:4,f:18,
  ing:[["Kiaušiniai",3,"vnt",P],["Liesa varškė",60,"g",P],["Sūris",10,"g",P],["Šaldyti špinatai",30,"g",F],["Paprikos",30,"g",V]],
  prep:["Kiaušinius, varškę, špinatus, papriką ir sūrį sumaišyk, supilk į keksiukų formeles.","Kepk 180 °C ~20 min. Užtenka 3–4 dienoms, trečiadienį iškepk naują partiją."]},
 {id:"s2",s:"S",n:"Tirštas jogurtas su riešutais ir uogomis",d:"300 g tiršto jogurto (Skyr), 20 g graikinių riešutų, 100 g uogų",p:36,c:25,f:14,
  ing:[["Liesas tirštas jogurtas (Skyr)",300,"g",P],["Graikiniai riešutai",20,"g",O],["Šaldytos uogos",100,"g",F]],
  prep:["Sudėk į dėžutę iš vakaro – uogos atitirps iki ryto."]},
 {id:"s3",s:"S",n:"Tuno salotos su kiaušiniais",d:"Tuno skardinė, 2 kiaušiniai, 50 g graikiško jogurto, agurkas, kukurūzai",p:49,c:12,f:12,
  ing:[["Tunas savo sultyse (skardinė)",1,"vnt",S],["Kiaušiniai",2,"vnt",P],["Graikiškas jogurtas",50,"g",P],["Konservuoti kukurūzai (skardinė)",50,"g",S],["Agurkai",100,"g",V]],
  prep:["Kiaušinius išvirk greitpuodyje (5 min) visai savaitei, nulupk.","Salotas sumaišyk 3 dienoms į priekį."]},
 {id:"a1",s:"A",n:"Varškė su vaisiumi ir riešutais",d:"200 g liesos varškės, obuolys, 20 g riešutų",p:39,c:34,f:14,
  ing:[["Liesa varškė",200,"g",P],["Obuoliai",1,"vnt",V],["Graikiniai riešutai",20,"g",O]],
  prep:["Ruošti nereikia – tik įsidėk į dėžutę."]},
 {id:"a2",s:"A",n:"Baltymų kokteilis su bananu",d:"40 g baltymų, 400 ml pieno 1,5 %, bananas, 30 g avižų",p:50,c:67,f:10,
  ing:[["Išrūgų baltymų milteliai",40,"g",O],["Pienas 1,5–2,5 %",400,"ml",P],["Bananai",1,"vnt",V],["Avižiniai dribsniai",30,"g",K]],
  prep:["Sutrink blenderiu prieš valgant. Tinka ir prieš dviratį."]},
 {id:"a3",s:"A",n:"Varškėtukai orkaitėje",d:"250 g varškės, kiaušinis, 30 g avižų, uogos",p:55,c:34,f:8,
  ing:[["Liesa varškė",250,"g",P],["Kiaušiniai",1,"vnt",P],["Avižiniai dribsniai",30,"g",K],["Šaldytos uogos",80,"g",F]],
  prep:["Varškę, kiaušinius ir dribsnius sumaišyk, suformuok paplotėlius.","Kepk 190 °C 20 min. Valgyk šaltus su uogomis."]},
 {id:"d1",s:"D",n:"Jautienos chili su grikiais",d:"200 g liesos jautienos, pupelės, pomidorai + 80 g grikių (sausi)",p:61,c:81,f:13,
  ing:[["Liesa jautiena (faršas ar gabaliukai)",200,"g",M],["Konservuotos raudonosios pupelės (skardinė)",0.55,"vnt",S],["Konservuoti pomidorų gabaliukai (skardinė)",0.5,"vnt",S],["Grikiai",80,"g",K],["Svogūnai",40,"g",V],["Česnakai, kmynai, paprika",0,"",O]],
  prep:["Greitpuodyje apkepink faršą su svogūnais ir česnaku.","Sudėk pupeles, pomidorus, kmynus ir papriką. Aukštas slėgis 12 min.","Grikiai: 1 dalis grikių ir 2 vandens, 4 min."]},
 {id:"d2",s:"D",n:"Vištienos guliašas su ryžiais",d:"230 g vištienos, paprikos, pomidorai, grietinė + 90 g ryžių (sausi)",p:62,c:84,f:12,
  ing:[["Vištienos krūtinėlė",230,"g",M],["Paprikos",100,"g",V],["Svogūnai",40,"g",V],["Konservuoti pomidorų gabaliukai (skardinė)",0.3,"vnt",S],["Grietinė 10 %",30,"g",P],["Ryžiai",90,"g",K],["Alyvuogių aliejus",5,"ml",O]],
  prep:["Greitpuodyje apkepink svogūnus ir vištienos kubelius, sudėk paprikas, pomidorus ir saldžiąją papriką.","Aukštas slėgis 8 min, pabaigoje įmaišyk grietinę.","Ryžiai: 1 dalis ryžių ir 1,25 vandens, 4 min."]},
 {id:"d3",s:"D",n:"Kalakutienos bolonezė su makaronais",d:"220 g kalakutienos faršo, pomidorų padažas, morkos + 90 g pilno grūdo makaronų",p:66,c:84,f:15,
  ing:[["Kalakutienos krūtinėlės faršas",220,"g",M],["Trinti pomidorai (passata)",200,"g",S],["Svogūnai",40,"g",V],["Morkos",50,"g",V],["Pilno grūdo makaronai",90,"g",K],["Parmezano sūris",10,"g",P],["Alyvuogių aliejus",5,"ml",O]],
  prep:["Greitpuodyje apkepink faršą, svogūnus ir tarkuotas morkas, supilk passatą.","Aukštas slėgis 10 min.","Makaronus virk puode 2 kartus per savaitę – šildyti jie blogėja."]}
];
const STEPS={
 b1:{a:10,t:10,note:"+ per naktį šaldytuve",steps:[
  ["Paimk {n} stiklainius ar dėžutes su dangteliais – po vieną kiekvienai porcijai.",1],
  ["Į kiekvieną suberk {p0} avižinių dribsnių, {p1} išrūgų baltymų miltelių ir {p4} chia sėklų. Išmaišyk sausai, kad baltymai nesusigumuliuotų.",3],
  ["Į kiekvieną įdėk {p2} tiršto jogurto (Skyr) ir įpilk ~150 ml vandens ar pieno. Gerai išmaišyk šaukštu iki pat dugno.",4],
  ["Ant viršaus užberk {p3} šaldytų uogų, uždenk ir dėk į šaldytuvą. Valgyti galima po 4 val., laikosi 3–4 dienas.",2]]},
 b2:{a:8,t:8,note:"+ per naktį šaldytuve",steps:[
  ["Paimk {n} stiklainius ar dėžutes.",1],
  ["Į kiekvieną: {p0} avižinių dribsnių, {p1} liesos varškės ir {p2} išrūgų baltymų miltelių. Įpilk ~150 ml vandens ar pieno ir gerai išmaišyk.",5],
  ["Uždenk ir dėk į šaldytuvą per naktį. Laikosi 3 dienas.",1],
  ["Ryte ant viršaus supjaustyk bananą ir uždėk {p4} žemės riešutų sviesto.",2]]},
 b3:{a:20,t:55,steps:[
  ["Įkaitink orkaitę iki 180 °C. 1–2 skardas išklok kepimo popieriumi.",2],
  ["Dubenyje sumaišyk {0} avižinių dribsnių, kiaušinius ({1} vnt.) ir {2} liesos varškės. Įberk po ½ arbatinio šaukštelio kepimo miltelių kiekvienai porcijai ir cinamono.",5],
  ["Sutrink trintuvu arba gerai išplak šakute, kol masė vientisa. Palik 5 min, kad dribsniai išbrinktų.",5,1],
  ["Išpilk ~2 cm sluoksniu ir kepk 25–30 min, kol viršus auksinis, o centras nebelimpa prie dantų krapštuko.",28,1],
  ["Atvėsink 10 min, supjaustyk į {n} dalis ir sudėk į dėžutes. Tai, ką valgysi po 3 dienų, užšaldyk.",12],
  ["Valgant uždėk {p3} tiršto jogurto ir {p4} uogų.",1]]},
 l1:{a:20,t:45,steps:[
  ["Įkaitink orkaitę iki 200 °C. Dvi skardas išklok kepimo popieriumi.",2],
  ["{0} vištienos krūtinėlės nusausink popieriniu rankšluosčiu. Storas krūtinėles perpjauk išilgai pusiau, kad keptų tolygiai.",5],
  ["Dubenyje vištieną sumaišyk su puse aliejaus (iš viso {3}), 2 arbatiniais šaukšteliais paprikos, 1 a. š. česnako miltelių ir druska (~1 a. š. kilogramui).",3],
  ["Išdėliok vištieną ant skardos vienu sluoksniu ir dėk į orkaitę. Kepk 22–25 min, kol viduje nebeliks rausvumo.",24,1],
  ["Kol kepa – ryžiai: {1} ryžių nuplauk sietelyje, suberk į greitpuodį, įpilk 1,25 karto daugiau vandens (pagal tūrį) ir žiupsnelį druskos. Aukštas slėgis 4 min, tada leisk slėgiui nukristi pačiam ~10 min.",15,1],
  ["Ant antros skardos paskleisk {2} šaldytų daržovių, apšlakstyk likusiu aliejumi, pasūdyk ir kepk kartu su vištiena paskutines 15–18 min.",2],
  ["Vištieną palik pailsėti 5 min, tada supjaustyk griežinėliais.",6],
  ["Paskirstyk į {n} dėžutes: vištiena, ryžiai, daržovės. Atvėsink be dangčio 20–30 min, tada uždenk ir dėk į šaldytuvą ar šaldiklį.",5]]},
 l2:{a:25,t:45,steps:[
  ["Įkaitink orkaitę iki 200 °C (arba airfryer iki 190 °C). Skardą išklok kepimo popieriumi.",2],
  ["Grikiai: {1} grikių nuplauk, suberk į greitpuodį, įpilk 2 kartus daugiau vandens ir žiupsnelį druskos. Aukštas slėgis 4 min, tada slėgis krinta pats ~10 min.",15,1],
  ["{3} svogūnų smulkiai sutarkuok ir sumaišyk su {0} kalakutienos faršo, 2 česnako skiltelėmis, druska, pipirais ir paprika.",6],
  ["Drėgnomis rankomis suformuok delno dydžio kotletus (~80 g) ir sudėk ant skardos. Patepk aliejumi.",10],
  ["Kepk 18–20 min (airfryer – 12 min, per vidurį apversk), kol viduje nebeliks rausvumo.",20,1],
  ["Ant kitos skardos paskleisk {2} šaldytų daržovių, apšlakstyk likusiu aliejumi ir kepk 15 min.",2],
  ["Sudėk į {n} dėžutes, atvėsink 20 min ir uždenk.",5]]},
 l3:{a:20,t:40,steps:[
  ["{0} vištienos supjaustyk ~3 cm kubeliais, {4} svogūnų – smulkiai.",8],
  ["Greitpuodyje (troškinimo / sauté režimu) įkaitink šaukštą aliejaus ir 3 min pakepink svogūnus.",4],
  ["Sudėk vištieną ir kario pastą (~1 valgomąjį šaukštą 3 porcijoms). Maišydamas kepk 3 min.",3],
  ["Supilk {2} kokosų pieno, suberk {3} šaldytų daržovių, įpilk ~100 ml vandens, pasūdyk. Uždaryk dangtį: aukštas slėgis 6 min, tada slėgį išleisk rankiniu būdu.",15,1],
  ["Tuo metu ryžiai puode: {1} ryžių ir 2 kartus daugiau vandens, užvirus ant mažos ugnies uždengus 12–15 min.",15,1],
  ["Paragauk, jei reikia – pasūdyk ar įspausk citrinos. Sudėk į {n} dėžutes su ryžiais ir atvėsink.",5]]},
 s1:{a:12,t:35,steps:[
  ["Įkaitink orkaitę iki 180 °C. Keksiukų formą patepk aliejumi arba naudok silikonines formeles.",2],
  ["{4} paprikų supjaustyk smulkiais kubeliais. {3} šaldytų špinatų atitirpink ir nuspausk skystį.",5],
  ["Dubenyje išplak kiaušinius ({0} vnt.) su {1} liesos varškės, druska ir pipirais. Įmaišyk daržoves ir sutarkuotą {2} sūrio.",4],
  ["Pripildyk formeles iki ¾ (~3 keksiukai porcijai) ir kepk 20 min, kol centras sustingęs.",20,1],
  ["Atvėsink 5 min, išimk iš formelių ir sudėk į dėžutę su popieriniu rankšluosčiu apačioje. Laikosi 3–4 dienas.",6]]},
 s2:{a:4,t:4,steps:[
  ["Į {n} dėžutes sudėk po {p0} tiršto jogurto (Skyr).",2],
  ["Ant viršaus užberk po {p2} šaldytų uogų – iki ryto atitirps.",1],
  ["Riešutus (po {p1} porcijai) laikyk atskirai ir užberk prieš valgant, kad liktų traškūs.",1]]},
 s3:{a:15,t:30,steps:[
  ["Kiaušinius ({1} vnt.) sudėk į greitpuodį ant grotelių, įpilk 250 ml vandens. Aukštas slėgis 5 min, tada iš karto į šaltą vandenį 5 min.",15,1],
  ["Nulupk kiaušinius ir supjaustyk kubeliais.",5],
  ["Tuną ({0} skard.) nuvarvink, {4} agurkų supjaustyk kubeliais, {3} kukurūzų nuvarvink.",5],
  ["Viską sumaišyk su {2} graikiško jogurto, druska, pipirais ir citrinos sultimis. Sudėk į dėžutes – ne daugiau kaip 3 dienoms.",4]]},
 a1:{a:3,t:3,steps:[
  ["Į dėžutę sudėk {p0} liesos varškės.",1],
  ["Obuolį supjaustyk prieš valgant, kad neparuduotų, ir užberk {p2} graikinių riešutų.",2]]},
 a2:{a:2,t:2,steps:[
  ["Į trintuvą supilk {p1} pieno, suberk {p0} išrūgų baltymų miltelių ir {p3} avižinių dribsnių.",1],
  ["Įdėk nuluptą bananą ir trink 30–40 sek. Gerk iš karto.",1]]},
 a3:{a:15,t:45,steps:[
  ["Įkaitink orkaitę iki 190 °C, skardą išklok kepimo popieriumi.",2],
  ["Sumaišyk {0} liesos varškės, kiaušinius ({1} vnt.) ir {2} avižinių dribsnių. Įberk žiupsnelį druskos, vanilės ar saldiklio pagal skonį.",5],
  ["Palik 5 min, kad dribsniai išbrinktų, tada šaukštu suformuok ~2 cm storio paplotėlius (~3 porcijai).",8],
  ["Kepk 20 min, apversk ir kepk dar 5 min.",25,1],
  ["Atvėsink ir sudėk į dėžutes. Valgant užberk {p3} uogų.",5]]},
 d1:{a:25,t:50,steps:[
  ["{4} svogūnų ir 3–4 česnako skilteles supjaustyk smulkiai.",5],
  ["Greitpuodyje (sauté režimu) įkaitink šaukštą aliejaus ir 3 min kepk svogūnus.",4],
  ["Sudėk {0} liesos jautienos (faršo arba smulkiai pjaustytos), smulkink mentele ir kepk 6–8 min, kol neliks rausvumo.",8],
  ["Įberk kmynų, 2 a. š. paprikos ir druskos. Sudėk pomidorus ({2} skard.) ir nuvarvintas pupeles ({1} skard.), įpilk 100 ml vandens ir nugrandyk dugną, kad nepridegtų.",4],
  ["Uždaryk dangtį: aukštas slėgis 12 min, tada slėgis krinta pats ~10 min.",22,1],
  ["Tuo metu grikiai puode: {3} grikių, 2 kartus daugiau vandens ir druskos. Užvirus mažink ugnį ir virk uždengus 15 min.",18,1],
  ["Sudėk į {n} dėžutes – chili ir grikius atskirose pusėse. Atvėsink 30 min ir uždenk.",5]]},
 d2:{a:25,t:45,steps:[
  ["{0} vištienos supjaustyk kubeliais, {2} svogūnų ir {1} paprikų – juostelėmis.",10],
  ["Greitpuodyje (sauté režimu) su {6} aliejaus 3 min pakepink svogūnus, sudėk vištieną ir kepk dar 4 min.",7],
  ["Sudėk paprikas, pomidorus ({3} skard.), 2 a. š. saldžiosios paprikos, druskos ir 100 ml vandens.",3],
  ["Uždaryk dangtį: aukštas slėgis 8 min, tada slėgį išleisk rankiniu būdu.",15,1],
  ["Tuo metu ryžiai puode: {5} ryžių, 2 kartus daugiau vandens, užvirus ant mažos ugnies uždengus 12–15 min.",15,1],
  ["Išjungęs kaitinimą įmaišyk {4} grietinės (kad nesutrauktų). Sudėk į {n} dėžutes su ryžiais.",5]]},
 d3:{a:25,t:45,steps:[
  ["{2} svogūnų supjaustyk smulkiai, {3} morkų sutarkuok.",6],
  ["Greitpuodyje (sauté režimu) su {6} aliejaus 4 min pakepink svogūnus ir morkas.",5],
  ["Sudėk {0} kalakutienos faršo, smulkink mentele ir kepk 6 min.",7],
  ["Supilk {1} pomidorų passatos, įberk raudonėlio, druskos ir pipirų, įpilk 50 ml vandens. Aukštas slėgis 10 min, tada slėgį išleisk rankiniu būdu.",17,1],
  ["Tuo metu makaronai: virk puode pagal pakuotę (~10 min) tik 2–3 dienoms, po {p4} porcijai. Kitoms dienoms virk šviežius.",12,1],
  ["Padažą sudėk į dėžutes. Valgant užbarstyk {p5} parmezano.",4]]}
};
LIB.forEach(r=>Object.assign(r,STEPS[r.id]||{}));
const PROD={"varske":{"l":"Liesa varškė","q":"liesa varškė","m":"prot","w":"Daugiausia baltymų (19,8 g/100 g) beveik be riebalų. Jei nori pigiau – RIMI SMART 180 g: 3,83 €/kg, bet baltymų 16,2 g.","it":[[814681,"Varškė liesa RIMI, 0,5 % rieb., 500 g",500,"g",98,0.5,3.5,3.1,19.8,0.1,2.89],[813690,"Liesa varškė RIMI SMART, 0,5 % rieb., 180 g",180,"g",85,0.5,3.9,2.3,16.2,0.1,0.69],[295116,"Liesa DVARO varškė, 400 g",400,"g",87,0.5,3.5,3.0,17,0,3.59],[276597,"Liesa varškė VILVI, 0,5 % rieb., 180 g",180,"g",85,0.5,3.9,2.3,16.2,0,0.89],[252241,"ROKIŠKIO NAMINĖ varškė, 9 % rieb., 180 g",180,"g",159,9,3.5,2.9,16,0.1,1.39]]},"jog":{"l":"Liesas tirštas jogurtas (Skyr arba graikiškas)","q":"skyr","m":"prot","w":"SALLING SKYR – liesiausias (0,2 % rieb.) ir pigiausias per kilogramą (3,79 €/kg), sudėtis: tik nugriebtas pienas ir raugas. Graikiška AMFORA PROTEIN turi kiek daugiau baltymų, bet 2× brangesnė.","it":[[817521,"Natūralus jogurtas SALLING SKYR, 0,2 % rieb., 1 kg",1000,"g",56,0.2,3.5,3.0,10,0.1,3.79],[949228,"Varškė GRAIKIŠKA AMFORA PROTEIN, 0,9 % rieb., 200 g",200,"g",69,0.9,4.6,3.4,10.5,0.1,1.65],[903780,"Graikiškas jogurtas be priedų AISTĖ, 400 g",400,"g",62,2,2.3,2.3,9,0.2,1.89],[927768,"Graikiškas natūralus jogurtas GRAIKIŠKA AMFORA, 3,9 % rieb., 370 g",370,"g",88,3.9,4.2,3.6,9,0.1,1.99],[917033,"Graikiškas jogurtas ALMA, 4 % rieb., 370 g",370,"g",80,4,4,4,7,0.1,1.39]]},"whey":{"l":"Išrūgų baltymų milteliai","q":"baltymų milteliai","m":"prot","w":"Rimi e. parduotuvėje tikrų išrūgų baltymų pasirinkimas mažas: ISOSTAR turi 82 g baltymų/100 g, bet kaina ~40 €/kg – sporto mitybos parduotuvėse dažnai pigiau. Košei ar blynams galima naudoti skystus kiaušinių baltymus.","it":[[1017151,"Baltymų milteliai ISOSTAR, bananų skonio, 400 g",400,"g",373,2,5.9,1.8,82,0.6,15.99],[953461,"Kiaušinių baltymai BALTICOVO PREMIUM (skysti), 500 g",500,"g",45,0,0.7,0.7,10.5,0.3,2.49],[1017150,"ISOSTAR MASS GAINER (netinka – daug cukraus), 700 g",700,"g",366,0.4,67,49,24,0.6,14.99]]},"avizos":{"l":"Avižiniai dribsniai","q":"avižiniai dribsniai","m":"same","w":"Visų avižinių dribsnių sudėtis beveik vienoda (~12,5–14 g baltymų, <1,5 g cukraus), todėl rinkis pigiausią: RIMI 450 g – 2,20 €/kg.","it":[[801700,"Greitai paruošiami avižiniai dribsniai RIMI, 450 g",450,"g",368,7,58.7,0.7,12.5,0,0.99],[176797,"Visų grūdo dalių avižiniai dribsniai MALSENA, 1,5 kg",1500,"g",368,7,58.7,0.7,12.5,0,3.99],[100310,"Avižiniai dribsniai ELOVENA, 500 g",500,"g",370,8,55,1.2,14,0,2.79],[183037,"Ekologiški viso grūdo avižiniai dribsniai MALSENA, 400 g",400,"g",366,7.6,55.2,0.5,13,0,2.19]]},"vist":{"l":"Vištienos (viščiukų) krūtinėlės filė","q":"viščiukų krūtinėlių filė","m":"prot","w":"RIMI 500 g – liesa (1,5 % rieb.), 22 g baltymų ir pigiausia (6,98 €/kg). Ekologiška filė turi 4× daugiau riebalų ir kainuoja 3× brangiau.","it":[[813427,"Viščiukų krūtinėlių filė RIMI, 500 g",500,"g",102,1.5,0,0,22,0.2,3.49],[816943,"Viščiukų vidinė filė be antibiotikų RIMI, 400 g",400,"g",110,1.5,0,0,23.4,0,2.99],[971720,"Švieži viščiukų filė gabaliukai be antibiotikų, 500 g",500,"g",107,1.2,0,0,24.1,0.1,5.49],[815168,"Ekologiška vištienos krūtinėlės filė RIMI, 260 g",260,"g",148,6.8,0,0,21.6,0.1,5.99]]},"jaut":{"l":"Liesa jautiena (faršui ar troškiniui)","q":"jautiena stroganovietiškai","m":"prot","w":"Liesos (≤5 %) jautienos faršo Rimi e. parduotuvėje neradome. Liesiausia – „Jautiena Stroganovietiškai“ (3,6 % rieb.): smulkiai supjaustyk chili. Įprastas faršas (18–20 % rieb.) 200 g porcijai prideda ~20 g riebalų.","it":[[814586,"Jautiena Stroganovietiškai RIMI (gabaliukai), 400 g",400,"g",116,3.6,0,0,20.9,0.2,7.49],[813281,"Jautienos kumpio kepsnys RIMI, 200 g",200,"g",114,2,0.7,0.7,23.2,0.1,7.49],[807871,"Atšaldyta smulkinta jautiena RIMI, 18 % rieb., 1 kg",1000,"g",199,14.5,0,0,17,0.4,4.4],[816059,"Jautienos faršas RIMI SMART, 400 g",400,"g",238,20,0.5,0.5,14,1.1,3.99]]},"kalak":{"l":"Kalakutienos krūtinėlės faršas","q":"kalakutų filė","m":"prot","w":"Kalakutų filė – 25 g baltymų ir tik 1,2 g riebalų (sumalk smulkintuvu arba smulkiai supjaustyk). Paruoštas kalakutienos faršas pigesnis, bet riebalų 10× daugiau (12 g).","it":[[809473,"Kalakutų filė RIMI, 1 kg",1000,"g",111,1.2,0,0,25,0.1,15.59],[809287,"Kalakutienos faršas RIMI, 500 g",500,"g",182,12.1,0.4,0,17.8,1.1,3.79],[4012142,"Kalakutienos petukų faršas ARVI, 400 g",400,"g",159,10,2.6,0.5,14,1.3,3.99],[815175,"Ekologiškas vištienos faršas RIMI, 300 g",300,"g",170,10,0,0,18.1,0.1,5.99]]},"ryziai":{"l":"Ryžiai (basmati)","q":"basmati ryžiai","m":"same","w":"Basmati ryžių sudėtis panaši; GRALLA 800 g – pigiausi (3,74 €/kg) ir turi 8 g baltymų.","it":[[1006448,"Ilgagrūdžiai BASMATI ryžiai GRALLA, 800 g",800,"g",353,1.3,76.5,0.3,8,0,2.99],[817464,"Basmati ryžiai RIMI PLANET, 4×100 g",400,"g",358,1.1,76.5,0.3,9.4,0,2.08],[192692,"Basmati ryžiai CROWN OF HIMALAYA, 800 g",800,"g",350,0.5,79.7,0,6.9,0,3.99]]},"grikiai":{"l":"Grikių kruopos","q":"grikių kruopos","m":"same","w":"EKOFRISA – pigiausi (2,11 €/kg) ir daugiausia baltymų (13,2 g).","it":[[129516,"Grikių kruopos EKOFRISA, 800 g",800,"g",362,2.9,70.6,2,13.2,0,1.69],[153320,"Grikių kruopos SKANĖJA, 800 g",800,"g",367,3.1,69.3,0.7,12.6,0,2.99],[182256,"Neskrudintos grikių kruopos GALINTA, 800 g",800,"g",367,3.1,69.3,0.7,12.6,0,2.99],[810608,"Žalieji grikiai RIMI, 800 g",800,"g",367,3.1,69.3,0.7,12.6,0,3.19]]},"makar":{"l":"Pilno grūdo makaronai","q":"pilno grūdo makaronai","m":"carb","w":"LUBELLA spagečiai – daugiausia baltymų (15,2 g) ir mažiausiai cukraus (0,7 g).","it":[[153070,"Pilno grūdo spagečiai LUBELLA, 400 g",400,"g",357,1.3,68,0.7,15.2,0,1.79],[182147,"Pilno grūdo makaronai LA MOLISANA RADIATORINI, 500 g",500,"g",347,2,67,2.7,12,0,1.99],[168506,"Pilno grūdo makaronai SPAGHETTI INTEGRALE, 500 g",500,"g",350,2.5,65.7,3.5,13,0,2.29]]},"kiaus":{"l":"Kiaušiniai","q":"kiaušiniai","m":"same","w":"Vištų kiaušinių sudėtis vienoda (12,5 g baltymų/100 g) – rinkis pigiausius: RIDO 10 vnt. – 0,30 €/vnt.","it":[[930451,"LAIMINGI kiaušiniai RIDO, 10 vnt.",10,"vnt",130,8.5,0.9,0.2,12.5,0.3,2.99],[813372,"Ekologiški vištų kiaušiniai Rimi Eco, M/L, 10 vnt.",10,"vnt",139,9.7,0.6,0,12.5,0.4,3.49]]},"pupel":{"l":"Konservuotos raudonosios pupelės","q":"raudonosios pupelės","m":"can","w":"RIMI – be cukraus, mažai druskos ir pigiausios (0,99 € skardinė).","it":[[808449,"Raudonosios pupelės RIMI, 400 g / 240 g",1,"vnt",110,0.5,14.8,0,7.4,0.7,0.99],[101302,"Raudonosios pupelės BONDUELLE KIDNEY, 400 g / 250 g",1,"vnt",105,0.7,13.2,0.8,8.2,0.7,2.29],[1020302,"Ekologiškos raudonosios pupelės ACTIVUS (be skysčio), 150 g",1,"vnt",129,0.4,19,0.9,9.2,0.8,1.55]]},"pomid":{"l":"Konservuoti pomidorų gabaliukai","q":"pomidorų gabaliukai","m":"can","w":"MUTTI turi mažiausiai cukraus (2,8 g), RIMI – be druskos ir pigesni. Abu tinka.","it":[[807736,"Pomidorų gabaliukai RIMI, 400 g",1,"vnt",28,0.1,4.9,4.8,1.6,0,1.55],[964982,"Smulkiai pjaustyti pomidorai MUTTI, 400 g",1,"vnt",26,0.2,3.9,2.8,1.2,0.3,2.39]]},"passata":{"l":"Trinti pomidorai (passata)","q":"passata","m":"can","w":"Vienintelė rasta passata – RIMI 500 g: be priedų, 3,6 g cukraus.","it":[[811905,"Pomidorų PASSATA RIMI, 500 g",500,"g",31,0,5.4,3.6,1.5,0.5,1.99]]},"tunas":{"l":"Tunas savo sultyse","q":"tunas savo sultyse","m":"prot","w":"Visi tunai savo sultyse panašūs (24–27 g baltymų); RIMI MSC – pigiausias skardinei.","it":[[803886,"Tuno gabaliukai savo sultyse RIMI MSC, 185 g",1,"vnt",108,0.6,0.1,0,25.6,1,2.79],[948729,"Tunai savo sultyse JOHN WEST, 160 g",1,"vnt",113,0.5,0,0,27,0.9,3.59],[289973,"Nesmulkintas tunas savo sultyse CALVO, 240 g",1,"vnt",103,0.8,0,0,24,0.6,5.49]]},"pienas":{"l":"Pienas","q":"pienas 2,5","m":"same","w":"1,5 % pieno Rimi e. parduotuvėje neradome – artimiausias 2,5 % (≈+1 g riebalų 100 ml). ROKIŠKIO NAMINIS ir DVARO vienodi.","it":[[4000040,"ROKIŠKIO NAMINIS pienas, 2,5 % rieb., 1 l",1000,"ml",53,2.5,4.5,4.5,3.2,0.1,1.29],[226054,"DVARO pienas, 2,5 % rieb., 1 l",1000,"ml",54,2.5,4.7,4.7,3.2,0.1,1.29],[212915,"Natūralus DVARO pienas, 3,5 % rieb., 1 l",1000,"ml",63,3.5,4.7,4.7,3.2,0.1,1.55]]},"walnut":{"l":"Graikiniai riešutai","q":"graikiniai riešutai","m":"nut","w":"RIMI 700 g – didelė pakuotė, mažiausiai angliavandenių ir pigiausia kilogramui.","it":[[814918,"Graikiniai riešutai RIMI, 700 g",700,"g",704,68,3.5,2.2,17,0,8.59],[804398,"Gliaudyti graikiniai riešutai AWAKE, 150 g",150,"g",716,65.2,13.7,2.6,15.2,0,1.65],[147055,"Graikiniai riešutai ARIMEX, 100 g",100,"g",688,60.4,14.6,3.4,18.5,0,1.99]]},"chia":{"l":"Ispaninio šalavijo (chia) sėklos","q":"ispaninio šalavijo sėklos","m":"nut","w":"ALVO – daugiausia baltymų (22 g) ir mažiausiai cukraus. Chia sėklose ~34 g skaidulų/100 g (Rimi jų nenurodo).","it":[[1012970,"Ekologiškos ispaninio šalavijo sėklos ALVO, 300 g",300,"g",448,33,2.1,0.4,22,0,5.99],[812878,"Šalavijų sėklos RIMI, 150 g",150,"g",466,33.4,4.9,0.7,20.3,0,3.09],[171309,"Ispaninių šalavijų sėklos AMRITA, 300 g",300,"g",434,31.2,13,1.2,17.6,0,6.49]]},"pb":{"l":"Žemės riešutų sviestas (kremas)","q":"žemės riešutų kremas","m":"nut","w":"ALVO 1 kg – 27 g baltymų, mažai cukraus (3,7 g) ir pigiausias (7,99 €/kg). Venk šokoladinių kremų – juose ~57 g cukraus.","it":[[1004578,"Žemės riešutų kremas ALVO, 1 kg",1000,"g",637,53,9.3,3.7,27,0,7.99],[197350,"Švelnus žemės riešutų kremas ULDUKAS, 300 g",300,"g",625,51,13,2,26,0,3.89],[165526,"Šokolado ir riešutų kremas NUTELLA (netinka), 600 g",600,"g",546,31.6,57.6,56.8,6,0.1,7.99]]},"kokos":{"l":"Kokosų pienas (sumažinto riebumo)","q":"kokosų pienas","m":"lowf","w":"AJI – mažiausiai riebalų (6,5 g) ir pigiausias. Įprastas kokosų pienas turi 17–18 g riebalų/100 ml.","it":[[182692,"Kokosų gėrimas AJI, 400 ml",400,"ml",74,6.5,3.9,1,0.5,0.5,1.99],[196377,"Mažesnio riebumo kokosų pienas SANTA MARIA LIGHT, 250 ml",250,"ml",79,8,0.9,0.8,0.8,0,2.75],[810287,"Kokosų pienas Rimi Planet, 400 ml",400,"ml",165,17,2.9,2.5,0.5,0.2,2.39]]},"darz":{"l":"Šaldytų daržovių mišinys","q":"šaldytų daržovių mišinys","m":"low","w":"RIMI trijų daržovių mišinys – pigiausias, be pridėtų priedų. Brokoliai – daugiausia baltymų ir mažiausiai angliavandenių.","it":[[811170,"Šaldytas trijų daržovių mišinys RIMI, 400 g",400,"g",41,0.8,3.6,3.2,2.9,0.1,1.19],[808638,"Šaldyti brokoliai RIMI, 400 g",400,"g",39,0.9,1.8,1.5,4.4,0,1.89],[224240,"Šaldytų daržovių mišinys HORTEX MEXICO, 400 g",400,"g",56,0.4,7.5,0,3.6,0,1.59]]},"uogos":{"l":"Šaldytos uogos","q":"šaldytos uogos","m":"low","w":"Braškės – beveik 3× mažiau cukraus nei šilauogės ir pigesnės.","it":[[811670,"Šaldytos braškės RIMI, 400 g",400,"g",35,0.3,8,4.9,0.7,0,1.89],[811169,"Šaldytos šilauogės RIMI, 400 g",400,"g",65,0.5,13.7,13.7,0.7,0,3.49]]}};
const PMAP=[[/varšk/,"varske"],[/jogurt|skyr/,"jog"],[/išrūgų|baltymų milt/,"whey"],[/aviž/,"avizos"],[/vištien|viščiuk/,"vist"],[/jautien/,"jaut"],[/kalakut/,"kalak"],[/ryž/,"ryziai"],[/grik/,"grikiai"],[/makaron/,"makar"],[/kiauš/,"kiaus"],[/pupel/,"pupel"],[/passata|trinti pomidor/,"passata"],[/pomidor/,"pomid"],[/^tun|tunas/,"tunas"],[/^pienas/,"pienas"],[/graikini/,"walnut"],[/šalavij|chia/,"chia"],[/žemės riešutų/,"pb"],[/kokos/,"kokos"],[/daržovių mišin/,"darz"],[/šaldytos uogos|^uogos/,"uogos"]];
const pkey=n=>{const s=String(n).toLowerCase();const m=PMAP.find(([re])=>re.test(s));return m?m[1]:null};
const PDATE="2026-11-23";
const DEF={B:"b1",L:"l1",S:"s1",A:"a1",D:"d1"};
const RX=[
 ["pork","Be kiaulienos",/kiaul|šonin|kumpi|dešr/],
 ["sea","Be jūros gėrybių (krevetės, midijos, kalmarai…)",/krevet|midij|kalmar|krab|aštuonkoj|omar|austr|šukut/],
 ["pot","Be bulvių",/bulv/],
 ["bread","Be duonos, trapučių, lavašų",/duon|trapuč|lavaš|baton/],
 ["veg","Vegetariška (be mėsos ir žuvies)",/vištien|kalakut|jautien|faršas|tunas|lašiš|kiaul|mėsa/]
];
const EQ=[["hob","Kaitlentė (viryklė)"],["ov","Orkaitė"],["gp","Greitpuodis (Instant Pot ir pan.)"],["af","Oro gruzdintuvė (airfryer)"],["mw","Mikrobangė"],["bl","Trintuvas (blenderis)"],["sc","Lėtpuodis"],["fz","Šaldiklis"]];
const E=k=>!!st.prof.eq[k];
const ALT={
 l1:{0:{af:["Įkaitink airfryer iki 190 °C.",2],pan:["Įkaitink didelę keptuvę ant vidutinės ugnies.",2]},
  3:{af:["Kepk vištieną airfryer krepšelyje vienu sluoksniu (dalimis) 14–16 min, per vidurį apversk, kol viduje nebeliks rausvumo.",30,1],pan:["Kepk vištieną keptuvėje dalimis po 5–6 min iš kiekvienos pusės, kol viduje nebeliks rausvumo.",25]},
  4:{gp:["Ryžiai puode: {1} ryžių nuplauk, užpilk 2 kartus daugiau vandens, pasūdyk. Užvirus mažink ugnį ir virk uždengus 12–15 min.",15,1]},
  5:{af:["Daržoves ({2}) kepk airfryer 10–12 min po vištienos arba troškink keptuvėje su aliejumi 8 min.",10,1],pan:["Daržoves ({2}) troškink keptuvėje su likusiu aliejumi 8–10 min.",10]}},
 l2:{0:{af:["Įkaitink airfryer iki 190 °C.",2],pan:["Įkaitink didelę keptuvę su šaukštu aliejaus ant vidutinės ugnies.",2]},
  1:{gp:["Grikiai puode: {1} grikių nuplauk, užpilk 2 kartus daugiau vandens, pasūdyk. Užvirus mažink ugnį ir virk uždengus 15 min.",18,1]},
  4:{af:["Kepk kotletus airfryer dalimis po 12 min, per vidurį apversk, kol viduje nebeliks rausvumo.",24,1],pan:["Kepk kotletus keptuvėje dalimis po 4–5 min iš kiekvienos pusės, kol viduje nebeliks rausvumo.",20]},
  5:{af:["Daržoves ({2}) kepk airfryer 10–12 min arba troškink keptuvėje.",10,1],pan:["Daržoves ({2}) troškink keptuvėje su likusiu aliejumi 8–10 min.",10]}},
 l3:{1:{gp:["Didelėje keptuvėje ar puode įkaitink šaukštą aliejaus ir 3 min pakepink svogūnus.",4]},
  3:{gp:["Supilk {2} kokosų pieno, suberk {3} šaldytų daržovių, įpilk ~100 ml vandens, pasūdyk. Uždenk ir troškink ant mažos ugnies 15–20 min, kol vištiena minkšta.",20,1]}},
 b3:{0:{af:["Įkaitink airfryer iki 170 °C, krepšelį ar formelę išklok kepimo popieriumi.",2],pan:["Įkaitink keptuvę su lašu aliejaus ant vidutinės ugnies.",2]},
  2:{bl:["Gerai išplak šakute, kol masė vientisa. Palik 5 min, kad dribsniai išbrinktų.",5,1]},
  3:{af:["Išpilk ~2 cm sluoksniu į formelę ir kepk dalimis po 15–18 min, kol viršus auksinis, o centras nebelimpa.",36,1],pan:["Kepk nedidelius blynelius po 2–3 min iš kiekvienos pusės, dalimis.",25]},
  4:{pan:["Atvėsink, sudėk į {n} dėžutes. Tai, ką valgysi po 3 dienų, užšaldyk.",5]}},
 s1:{0:{af:["Įkaitink airfryer iki 160 °C. Naudok silikonines keksiukų formeles.",2],pan:["Įkaitink keptuvę (su dangčiu) su lašu aliejaus ant mažos ugnies.",2]},
  3:{af:["Pripildyk formeles iki ¾ ir kepk airfryer dalimis po 12–14 min, kol centras sustingęs.",26,1],pan:["Supilk masę į keptuvę, uždenk ir kepk ant mažos ugnies 10–12 min kaip storą omletą. Apversk lėkšte ir kepk dar 3 min, supjaustyk gabalais.",15]}},
 a3:{0:{af:["Įkaitink airfryer iki 180 °C, krepšelį išklok kepimo popieriumi.",2],pan:["Įkaitink keptuvę su lašu aliejaus ant vidutinės ugnies.",2]},
  3:{af:["Kepk airfryer dalimis po 12 min, po 8 min apversk.",24,1],pan:["Kepk keptuvėje dalimis po 3–4 min iš kiekvienos pusės.",16]}},
 a2:{0:{bl:["Į šeikerį ar stiklainį su dangteliu supilk {p1} pieno, suberk {p0} išrūgų baltymų miltelių ir {p3} avižinių dribsnių.",1]},
  1:{bl:["Bananą sutrink šakute, sudėk į šeikerį ir stipriai plak 30 sek. Gerk iš karto.",2]}},
 s3:{0:{gp:["Kiaušinius ({1} vnt.) sudėk į puodą, užpilk šaltu vandeniu, užvirink ir virk 9 min, tada 5 min į šaltą vandenį.",15,1]}},
 d1:{1:{gp:["Dideliame puode įkaitink šaukštą aliejaus ir 3 min kepk svogūnus.",4]},
  4:{gp:["Uždenk ir troškink ant mažos ugnies 30 min, kas 10 min pamaišyk. Jei per tiršta – įpilk šlakelį vandens.",30,1]}},
 d2:{1:{gp:["Dideliame puode ar keptuvėje su {6} aliejaus 3 min pakepink svogūnus, sudėk vištieną ir kepk dar 4 min.",7]},
  3:{gp:["Uždenk ir troškink ant mažos ugnies 20 min, kartais pamaišyk.",20,1]}},
 d3:{1:{gp:["Dideliame puode su {6} aliejaus 4 min pakepink svogūnus ir morkas.",5]},
  3:{gp:["Supilk {1} pomidorų passatos, įberk raudonėlio, druskos ir pipirų, įpilk 50 ml vandens. Troškink uždengus ant mažos ugnies 20 min, kartais pamaišyk.",20,1]}}
};
const NEED={l1:[["ov","af","hob"]],l2:[["ov","af","hob"]],b3:[["ov","af","hob"]],s1:[["ov","af","hob"]],a3:[["ov","af","hob"]],l3:[["gp","hob"]],s3:[["gp","hob"]],d1:[["gp","hob"]],d2:[["gp","hob"]],d3:[["hob"]]};
const EQN=Object.fromEntries(EQ);
const eqViol=r=>(NEED[r.id]||[]).filter(g=>!g.some(E)).map(g=>"reikia: "+g.map(k=>EQN[k].split(" (")[0].toLowerCase()).join(" arba "));
/* ---------- ALERGENAI, ŽUVIS, LAISVAS TEKSTAS ---------- */
const ALG=[["gluten","Gliutenas",/aviž|makaron|kvieč|miltai|duon|bulgur|kuskus|rugi|miež|spelt|manų|kario pasta/],["crust","Vėžiagyviai",/krevet|krab|omar|vėži/],["egg","Kiaušiniai",/kiauš/],["fish","Žuvis",/tun|lašiš|menk|silk|skumbr|žuv|ančiuv|upėtak/],["peanut","Žemės riešutai",/žemės riešut|arachi/],["soy","Soja",/soj|tofu|edamam/],["milk","Pienas ir laktozė",/varšk|jogurt|skyr|sūr|grietin|parmez|išrūgų|^pienas|kefyr|sviestas(?!.*riešut)/],["nuts","Riešutai (medžių)",/graikini|migdol|lazdyn|anakard|pistac|pekan|makadam|brazil/],["celery","Salierai",/saler/],["mustard","Garstyčios",/garstyč/],["sesame","Sezamas",/sezam|tahin/],["sulph","Sulfitai",/vyn|sulfit/],["lupin","Lubinai",/lubin/],["moll","Moliuskai",/midij|kalmar|aštuonkoj|austr|šukut|sraig/]];
const FISHN={all:"Valgau žuvį",ts:"Tik tuną ir lašišą",none:"Žuvies nevalgau"};
const fold=s=>String(s||"").toLowerCase().replace(/[ąčęėįšųūž]/g,c=>({ą:"a",č:"c",ę:"e",ė:"e",į:"i",š:"s",ų:"u",ū:"u",ž:"z"}[c]));
const ENDS=["iams","ams","oms","ems","ims","ais","iu","ai","ei","es","as","is","ys","us","os","ui","a","e","i","u","o","s"];
const stem=w=>{w=fold(w).replace(/[^a-z]/g,"");for(const e of ENDS)if(w.length-e.length>=3&&w.endsWith(e))return w.slice(0,-e.length);return w};
const lev=(a,b)=>{if(a===b)return 0;const m=a.length,n=b.length;if(!m||!n)return m||n;let p=[...Array(n+1).keys()];for(let i=1;i<=m;i++){const c=[i];for(let j=1;j<=n;j++)c[j]=Math.min(p[j]+1,c[j-1]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));p=c}return p[n]};
const near=(w,t)=>{if(w.length<3||t.length<3)return w===t;if(Math.min(w.length,t.length)>=4&&(w.startsWith(t)||t.startsWith(w)))return true;return t.length>=4&&lev(w,t)<=(t.length>=7?2:1)};
const KW=[[["kiaul","kumpi","sonin","desr","lasin"],"rx","pork"],[["jur","krevet","midij","kalmar","krab","moliusk","vezia","austr"],"rx","sea"],[["zuv","zuvi"],"fish","none"],
 [["laktoz","pien","varsk","jogurt","suri","grietin","kefyr"],"alg","milk"],[["gliut","glitim","kviec","celiak"],"alg","gluten"],[["kiaus"],"alg","egg"],[["arach"],"alg","peanut"],
 [["riesut","migdol","lazdyn","anakard","pistac"],"alg","nuts"],[["soj","tofu"],"alg","soy"],[["sezam"],"alg","sesame"],[["saler"],"alg","celery"],[["garstyc"],"alg","mustard"],[["sulfit"],"alg","sulph"],[["lubin"],"alg","lupin"],
 [["vegetar","vegan"],"rx","veg"],[["bulv"],"rx","pot"],[["duon","trapuc","lavas","batono"],"rx","bread"]];
const STOP=new Set(["nevalgau","nemegstu","nemegst","alergij","alergisk","netoleruoj","netoleruoju","be","ir","ar","man","nes","labai","visai","joki","tik","nenoriu","negaliu","valgau","nevalg","nemeg","mano","yra","kai","del","jog","kad","noriu","patink","nepatink","geryb","gerybi","produkt","maist","valgyt","vartot","toler","netur"]);
const FSTOP=["nevalgau","nemegstu","alergij","alergisk","netoleruoj","nenoriu","negaliu"];const isStop=(w,s)=>STOP.has(w)||STOP.has(s)||FSTOP.some(x=>lev(s,x)<=1||lev(w.slice(0,x.length),x)<=1);
const parseFree=txt=>{const out={rx:{},alg:{},fish:null,words:[]};const f=fold(txt);if(/zemes\s*riesut/.test(f))out.alg.peanut=1;
 String(txt||"").split(/[,;.\n]+|\s+ir\s+/).forEach(part=>{const ws=fold(part).split(/[^a-z]+/).filter(Boolean);let hit=false;
  ws.forEach((w,i)=>{if(w.length<3||isStop(w,stem(w)))return;const s=stem(w);if((w==="zemes"||s==="zem")&&/riesut/.test(ws[i+1]||""))return;if(/^riesut/.test(s)&&ws[i-1]==="zemes")return;
   const kw=KW.find(([ps])=>ps.some(p=>s.startsWith(p)||w.startsWith(p)||(p.length>=4&&lev(s.slice(0,p.length),p)<=1)));
   if(kw){hit=true;if(kw[1]==="fish")out.fish=kw[2];else out[kw[1]][kw[2]]=1}else out.words.push(s)})});
 out.words=[...new Set(out.words)].filter(w=>w.length>=3);return out};
const PF=()=>parseFree(st.prof.dislike);
const algOf=r=>ALG.filter(([,,re])=>(r.ing||[]).some(i=>re.test(String(i[0]).toLowerCase()))).map(x=>x[0]);
const recog=p=>{const a=[];Object.keys(p.rx).forEach(k=>{const x=RX.find(r=>r[0]===k);if(x)a.push(x[1])});Object.keys(p.alg).forEach(k=>{const x=ALG.find(r=>r[0]===k);if(x)a.push("Alergija: "+x[1].toLowerCase())});if(p.fish)a.push(FISHN[p.fish]);p.words.forEach(w=>a.push("Nemėgsti: "+w+"…"));return a};
const PDEF={sex:"m",age:32,h:194,w:108,move:"1.35",str:3,strMin:60,end:2,endMin:60,goal:"lose",pace:"mid",pkg:2.3,meals:5,prep:4,trips:1,people:[],mode:"std",fish:"all",wmode:"raw",alg:{},eq:{hob:1,ov:1,gp:1,af:1,mw:0,bl:1,sc:0,fz:1},rx:{pork:1,sea:1,pot:1,bread:1,dairy:0,gluten:0,veg:0},dislike:"",equip:"greitpuodis, orkaitė, airfryer, didelis šaldiklis; nėra mikrobangės"};
const GOALS={lose:{slow:.9,mid:.83,fast:.77},recomp:.95,maintain:1,gain:{slow:1.05,mid:1.1,fast:1.15}};
const GNAME={lose:"Numesti riebalų",recomp:"Rekompozicija",maintain:"Išlaikyti svorį",gain:"Priaugti raumenų"};

const get=(k,d)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}};
const set=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const $=s=>document.querySelector(s);

const NEWU=!get("mp2",null);let st=get("mp2",null)||{menu:{...DEF},custom:[]};
if(!st.menu)st.menu={...DEF};if(!Array.isArray(st.custom))st.custom=[];
st.prof={...PDEF,...(st.prof||{})};st.prof.rx={...PDEF.rx,...(st.prof.rx||{})};st.prof.eq={...PDEF.eq,...(st.prof.eq||{})};st.prof.alg={...(st.prof.alg||{})};if(st.prof.rx.dairy){st.prof.alg.milk=1;delete st.prof.rx.dairy}if(st.prof.rx.gluten){st.prof.alg.gluten=1;delete st.prof.rx.gluten}if(!((get("mp2",{})||{}).prof||{}).fish)st.prof.fish=(st.prof.rx&&st.prof.rx.sea&&!NEWU)?"ts":"all";if(!st.prof.mode)st.prof.mode="std";if(!st.prof.wmode)st.prof.wmode="raw";
const normState=()=>{if(!st.menu)st.menu={...DEF};if(!Array.isArray(st.custom))st.custom=[];st.prof={...PDEF,...(st.prof||{})};st.prof.rx={...PDEF.rx,...(st.prof.rx||{})};st.prof.eq={...PDEF.eq,...(st.prof.eq||{})};st.prof.alg={...(st.prof.alg||{})};if(!Array.isArray(st.prof.people))st.prof.people=[];if(!st.prof.mode)st.prof.mode="std";if(!st.prof.wmode)st.prof.wmode="raw";if(!st.prof.fish)st.prof.fish="all"};
const num=(v,d)=>{const n=parseFloat(String(v).replace(",","."));return Number.isFinite(n)?n:d};
/* Baltymai: mokslinė rekomendacija (ISSN, Morton 2018, Helms 2014) ir sporto bendruomenių praktika + 10 % atsargai raumenims */
const protRec=p=>{const w=num(p.w,80),h=num(p.h,175)/100,bmi=w/(h*h),trains=num(p.str,0)+num(p.end,0)>0,str=num(p.str,0)>0;
 let base,why;
 if(p.goal==="gain"){base=2.0;why="Raumenų auginimui tyrimai rodo 1,6–2,2 g/kg, sporto bendruomenėse įprasta ~2 g/kg"}
 else if(p.goal==="lose"||p.goal==="recomp"){base=trains?2.2:1.6;why=trains?"Mažinant kalorijas ir sportuojant raumenims išsaugoti rekomenduojama 1,8–2,7 g/kg":"Mažinant kalorijas raumenims išsaugoti – bent 1,6 g/kg"}
 else{base=str?1.6:1.1;why=str?"Raumenims išlaikyti sportuojant – 1,4–2,0 g/kg (plato ties ~1,6 g/kg)":"Sveikam nesportuojančiam suaugusiam – ~0,8–1,2 g/kg"}
 const boost=(p.goal==="gain"||p.goal==="lose"||p.goal==="recomp"||str)?1.1:1;const rec=Math.min(3,Math.round(base*boost*10)/10);
 const eff=p.pkgManual?num(p.pkg,rec):rec;const wt=bmi>30?Math.round((25*h*h+(w-25*h*h)*.25)*10)/10:w;
 return {base,rec,eff,boost:boost>1,why,wt,adj:bmi>30}};
const calc=()=>{const p=st.prof,w=num(p.w,108),h=num(p.h,194),a=num(p.age,32);
 const bmr=10*w+6.25*h-5*a+(p.sex==="f"?-161:5);
 const ex=(num(p.str,0)*num(p.strMin,0)/60*5+num(p.end,0)*num(p.endMin,0)/60*7)*w/7;
 const tdeeF=bmr*num(p.move,1.35)+ex,tdee=num(p.tdeeAdj,0)>800?num(p.tdeeAdj,0):tdeeF;
 const g=GOALS[p.goal]??1,fct=typeof g==="number"?g:(g[p.pace]||g.mid);
 const kcalRec=Math.round(tdee*fct/10)*10,kcal=num(p.kcalMan,0)>500?Math.round(num(p.kcalMan,0)):kcalRec;
 const pr=protRec(p),P=Math.round(pr.eff*pr.wt),Fa=Math.max(Math.round(.6*w),Math.round(kcal*.23/9)),C=Math.max(0,Math.round((kcal-P*4-Fa*9)/4));
 return {pr,kcalRec,tdeeF:Math.round(tdeeF),adapt:num(p.tdeeAdj,0)>800,man:num(p.kcalMan,0)>500,age:a,w,bmr:Math.round(bmr),tdee:Math.round(tdee),kcal,p:P,c:C,f:Fa,fib:Math.round(kcal/1000*14),wk:(kcal-tdee)*7/7700}};
let T=calc();
const warnList=(R,p)=>{const o=[],w=num(p.w,80),fem=p.sex==="f",floor=fem?1200:1500,trainsEnd=num(p.end,0)>=2;
 if(R.kcal<floor)o.push(`${R.kcal} kcal – mažiau nei ${floor} kcal, kurias specialistai laiko minimumu ${fem?"moterims":"vyrams"} be gydytojo priežiūros. Gali trūkti vitaminų, mineralų ir energijos.`);
 else if(R.kcal<R.bmr)o.push(`${R.kcal} kcal – mažiau nei tavo bazinė apykaita (${R.bmr} kcal). Ilgainiui tai gali lėtinti medžiagų apykaitą ir mažinti raumenis.`);
 if(R.tdee&&R.kcal<R.tdee*.75)o.push(`Deficitas ${Math.round((1-R.kcal/R.tdee)*100)} % – didesnis nei rekomenduojami 15–25 %. Tikėtinas alkis, nuovargis, prastesnės treniruotės.`);
 if(R.wk<-w*.01)o.push(`Tikėtinas kritimas ${fmtN(Math.round(-R.wk*10)/10)} kg per savaitę – daugiau nei 1 % kūno svorio. Didėja rizika prarasti raumenis.`);
 if(R.age<18&&R.kcal<R.tdee)o.push("Augantiems paaugliams kalorijų deficitas nerekomenduojamas – pasitark su gydytoju ar dietologu.");
 if(R.pr.eff>3)o.push(`Baltymų ${fmtN(R.pr.eff)} g/kg – daugiau nei 3 g/kg papildomos naudos tyrimai neparodė. Jei turi inkstų ligų, pasitark su gydytoju.`);
 if(R.f<w*.5)o.push(`Riebalų tik ${R.f} g – mažiau nei 0,5 g/kg. Per mažai riebalų gali paveikti hormonus ir vitaminų įsisavinimą.`);
 if(trainsEnd&&R.c<3*w&&R.c<300)o.push(`Angliavandenių ${R.c} g – ištvermės treniruotėms dažnai rekomenduojama 3–5 g/kg (${Math.round(3*w)}–${Math.round(5*w)} g). Treniruotėse gali pritrūkti energijos.`);
 if(R.tdee&&R.kcal>R.tdee*1.15)o.push(`Perteklius ${Math.round((R.kcal/R.tdee-1)*100)} % – daugiau nei ~10–15 %, todėl didesnė dalis priaugto svorio bus riebalai.`);
 return o};
const DTYPES={rest:["Poilsis",-150,"Poilsio diena – šiek tiek mažiau angliavandenių."],str:["Jėga",0,""],end:["Ištvermė < 90 min",250,"Prieš treniruotę – bananas ar ryžių porcija."],long:["Ilga ištvermė 90+ min",600,"Važiuojant ar bėgant – 40–60 g angliavandenių per valandą (gelis, gėrimas, bananas)."]};
const dayT=d=>{const t=(LOG[d]||{}).dt,a=DTYPES[t]?DTYPES[t][1]:0;return {kcal:T.kcal+a,p:T.p,c:Math.max(0,T.c+Math.round(a/4)),f:T.f}};
const baseT=()=>SLOTS.reduce((a,s)=>({p:a.p+s.t.p,c:a.c+s.t.c,f:a.f+s.t.f}),{p:0,c:0,f:0});
const ACTN={low:"Mažas",mid:"Vidutinis",high:"Didelis"};
const pKcal=x=>{const a=num(x.age,30),f=x.sex==="f",act={low:.9,mid:1,high:1.15}[x.act]||1;
 if(a<18){const b=a<1?700:a<4?1050:a<7?1400:a<11?1750:a<15?(f?2050:2300):(f?2200:2800);return Math.round(b*act)}
 const w=num(x.w,f?65:80),h=f?165:178;return Math.round((10*w+6.25*h-5*a+(f?-161:5))*({low:1.4,mid:1.6,high:1.8}[x.act]||1.6))};
const HH=()=>1+(st.prof.people||[]).reduce((s,x)=>s+pKcal(x)/(T.kcal||2500),0);
const kids=()=>(st.prof.people||[]).some(x=>num(x.age,30)<14);
const dis=()=>PF().words;
const FISH_RE=/tun|lašiš|menk|silk|skumbr|žuv|ančiuv|upėtak|plekšn|lydek|karp|ešer/,TS_RE=/tun|lašiš/;
const viol=r=>{const names=(r.ing||[]).map(i=>String(i[0]).toLowerCase());const pf=PF();const rxOn=k=>st.prof.rx[k]||pf.rx[k];
 const out=RX.filter(([k,,re])=>rxOn(k)&&names.some(n=>re.test(n))).map(x=>x[1]);
 const fish=pf.fish||st.prof.fish;if(fish==="none"&&names.some(n=>FISH_RE.test(n)))out.push("Žuvies nevalgai");if(fish==="ts"&&names.some(n=>FISH_RE.test(n)&&!TS_RE.test(n)))out.push("Iš žuvies – tik tunas ir lašiša");
 const myA=new Set([...Object.keys(st.prof.alg||{}).filter(k=>st.prof.alg[k]),...Object.keys(pf.alg)]);algOf(r).filter(k=>myA.has(k)).forEach(k=>out.push("Alergenas: "+ALG.find(x=>x[0]===k)[1].toLowerCase()));
 const ws=[...names,r.n.toLowerCase()].flatMap(n=>fold(n).split(/[^a-z]+/)).filter(w=>w.length>=3).map(stem);
 pf.words.forEach(t=>{if(ws.some(w=>near(w,t)))out.push("Nemėgsti: "+t+"…")});return [...new Set([...out,...eqViol(r)])]};
let fac=1;
const scaleQ=(q,u)=>u==="vnt"?Math.round(q*2)/2:Math.round(q/5)*5;
const rawTag=(n,c)=>{const s=String(n).toLowerCase();if(/skardin|konserv|savo sultyse|rūkyt|virt/.test(s))return "";if(c===M||/vištien|viščiuk|kalakut|jautien|faršas|lašiš|filė|mėsa/.test(s))return " (žalia)";if(c===K&&/ryž|grik|makaron|spageč|kruop|bulgur|kuskus|aviž|quinoa|bolivin/.test(s))return /aviž/.test(s)?"":" (sausi)";return ""};
const YLD=n=>{const s=String(n).toLowerCase();if(/ryž/.test(s))return 2.8;if(/grik/.test(s))return 2.6;if(/makaron|spageč/.test(s))return 2.3;if(/bulgur|kuskus|kruop|bolivin|quinoa/.test(s))return 2.5;if(/jautien|faršas/.test(s))return .7;if(/lašiš|žuv|menk/.test(s))return .8;return .75};
const COOKED=()=>st.prof.wmode==="cooked";
const cookTag=t=>t===" (žalia)"?" (pagaminta)":t===" (sausi)"?" (išvirti)":t;
const wqty=(n,c,q)=>{const t=rawTag(n,c);return COOKED()&&t?{q:q*YLD(n),t:cookTag(t)}:{q,t}};
const descOf=(r,f)=>(r.ing||[]).filter(i=>i[1]>0).map(([n,q,u,c])=>{const w=u==="g"?wqty(n,c,q*f):{q:q*f,t:rawTag(n,c)};return `${String(scaleQ(w.q,u)).replace(".",",")} ${u==="vnt"?"vnt.":u} ${n.toLowerCase()}${w.t}`}).join(", ");
/* ---------- MAISTINĖ VERTĖ IŠ PREKIŲ ---------- */
// per 100 g/ml: [baltymai, angliav., riebalai]; vnt – vieneto svoris g
const GEN=[[/banan/,[1.1,23,0.3],120],[/obuol/,[0.3,14,0.2],180],[/špinat/,[2.9,1.4,0.4]],[/paprik/,[1,6,0.3]],[/svogūn/,[1.1,9,0.1]],[/mork/,[0.9,9.6,0.2]],[/agurk/,[0.7,3.6,0.1]],[/parmez/,[35,0,28]],[/sūris/,[25,0.5,28]],[/grietin/,[3,3.5,10]],[/aliej/,[0,0,92]],[/kukurūz/,[3,15,1.2],140],[/kario/,[2,10,8]],[/citrin/,[1,9,0.3],100]];
const UNITW={kiaus:53,pupel:240,pomid:400,tunas:130};
const prodSel=k=>{const PR=PROD[k];if(!PR)return null;const i=Math.min(PR.it.length-1,Math.max(0,num((st.psel||{})[k],0)));return PR.it[i]};
const nutOf=n=>{const k=pkey(n);if(k){const P=prodSel(k);if(P)return {v:[P[8],P[6],P[5]],w:P[3]==="vnt"&&P[2]>1?Math.round(530/10):UNITW[k]||100,k}}const s=String(n).toLowerCase();const g=GEN.find(([re])=>re.test(s));return g?{v:g[1],w:g[2]||100}:null};
const gramsOf=(q,u,nu)=>u==="g"||u==="ml"?q:u==="vnt"?q*(nu.w||100):0;
const isProtIng=n=>{const x=nutOf(n);if(!x)return false;const [p,c,f]=x.v;const e=p*4+c*4+f*9;return e>0&&p*4/e>=.4};
const macCalc=ing=>{let p=0,c=0,f=0,ok=true;(ing||[]).forEach(([n,q,u])=>{if(!(q>0)||!u)return;const x=nutOf(n);if(!x){ok=false;return}const g=gramsOf(q,u,x)/100;p+=x.v[0]*g;c+=x.v[1]*g;f+=x.v[2]*g});return {p:Math.round(p),c:Math.round(c),f:Math.round(f),ok}};
const macOf=r=>{const m=macCalc(r.ing);return m.ok?m:{p:r.p,c:r.c,f:r.f,ok:false}};
const splitMac=r=>{const pi=(r.ing||[]).filter(i=>isProtIng(i[0])),oi=(r.ing||[]).filter(i=>!isProtIng(i[0]));const a=macCalc(pi),b=macCalc(oi);if(a.ok&&b.ok)return {P:a,O:b};const m=macOf(r);return {P:{p:0,c:0,f:0},O:m}};
const fOf=(F,n)=>typeof F==="number"?F:(isProtIng(n)?F.p:F.o);
const view=(r,F=FAC[0])=>{const ing=r.ing.map(([n,q,u,c])=>[n,q*fOf(F,n),u,c]);const m=macCalc(ing);let p,c,f;
 if(m.ok){p=m.p;c=m.c;f=m.f}else{const fp=typeof F==="number"?F:F.p,fo=typeof F==="number"?F:F.o;p=Math.round(r.p*fp);c=Math.round(r.c*fo);f=Math.round(r.f*fo)}
 return {...r,p,c,f,exact:m.ok,ing,d:descOf({ing},1)}};
let shop=get("mp-shop2",[]);
let sample=null,busy=new Set();

const all=()=>[...LIB,...st.custom];
const VAR=()=>st.prof.mode==="var";
const mid=(k,s=0)=>{if(st.prof.mode==="one"&&k==="D"&&SLOTS.some(x=>x.k==="L"))return mid("L",s);if(s&&VAR()&&(k==="L"||k==="D")&&st.menuB&&st.menuB[k])return st.menuB[k];return st.menu[k]};
const rec=(k,s=0)=>all().find(r=>r.id===mid(k,s))||LIB.find(r=>r.id===DEF[k]);
let FAC=[{p:1,o:1},{p:1,o:1}];
const save=()=>{st.u=Date.now();set("mp2",st);syncState()};
const vrec=(k,s=0)=>view(rec(k,s),FAC[s]||FAC[0]);
const setOf=d=>{if(!VAR())return 0;const N=Math.min(7,Math.max(1,Math.round(num(st.prof.prep,4))));return Math.floor(pd(d).getDay()/N)%2};
const kc=m=>Math.round(m.p*4+m.c*4+m.f*9);
const sum=list=>list.reduce((a,r)=>({p:a.p+r.p,c:a.c+r.c,f:a.f+r.f}),{p:0,c:0,f:0});
const fmtN=n=>String(Math.round(n*10)/10).replace(".",",");
const macs=r=>`<span class="mac"><span>B ${r.p} g</span><span>A ${r.c} g</span><span>R ${r.f} g</span><span>${kc(r)} kcal</span></span>`;
const bars=(s,t)=>[["Baltymai","p","--p"],["Angliav.","c","--c"],["Riebalai","f","--f"]].map(([n,k,col])=>`<div class="tot-row"><span>${n}</span><div class="bar"><i style="width:${Math.min(100,s[k]/t[k]*100)}%;background:var(${col})"></i></div><b>${s[k]}/${t[k]} g</b></div>`).join("");

const MODEN={one:"Vienas patiekalas pietums ir vakarienei",std:"Atskiri pietūs ir vakarienė visą savaitę",var:"Kas gaminimą – vis kiti pietūs ir vakarienė"};
const slotLabel=sl=>st.prof.mode==="one"&&sl.k==="L"&&SLOTS.some(x=>x.k==="D")?"Pietūs ir vakarienė":sl.n;
const card=(sl,s)=>{const r=vrec(sl.k,s),key=sl.k+"|"+s,b=busy.has(key),v=viol(r),al=algOf(r);
 return `<div class="rc${b?" busy":""}"><span class="t">${slotLabel(sl)}${r.ai?" · sukūrė Claude":""}</span><h3>${esc(r.n)}</h3><p>${esc(r.d)}</p>${macs(r)}${timeChip(r)}${al.length?`<p class="small alg">Alergenai: ${al.map(k=>ALG.find(x=>x[0]===k)[1].toLowerCase()).join(", ")}</p>`:""}${v.length?`<p class="warn">Netinka tavo profiliui: ${esc(v.join(", "))}. Spausk „Kitas“.</p>`:""}<div class="acts"><button class="btn" data-next="${sl.k}" data-set="${s}"${b?" disabled":""}>Kitas</button><button class="btn pri ai" data-ai="${sl.k}" data-set="${s}"${sample?"":" hidden"}${b?" disabled":""}>${b?"Claude kuria…":"Naujas su Claude"}</button></div></div>`};
const renderMenu=()=>{
 const tot=sum(SLOTS.map(x=>vrec(x.k)));
 $("#planTot").innerHTML=`<div class="kcal"><span class="small">Meniu per dieną</span><strong>${kc(tot).toLocaleString("lt-LT")} kcal</strong></div>${bars(tot,T)}<p class="small">Tikslas pagal profilį: ${T.kcal.toLocaleString("lt-LT")} kcal · B ${T.p} g, A ${T.c} g, R ${T.f} g.${Math.abs(FAC[0].p-1)>=.03||Math.abs(FAC[0].o-1)>=.03?` Porcijos pritaikytos: baltyminiai produktai ×${FAC[0].p.toFixed(2).replace(".",",")}, kiti ×${FAC[0].o.toFixed(2).replace(".",",")}.`:""} Makro skaičiuojami iš realios prekių sudėties.</p><p class="small"><b>Gaminimo būdas:</b> ${MODEN[st.prof.mode]||MODEN.std} (keisk Profilyje).</p>`;
 const shown=SLOTS.filter(sl=>!(st.prof.mode==="one"&&sl.k==="D"&&SLOTS.some(x=>x.k==="L")));
 if(VAR()){const ss=sessions();const da=ss.filter(s=>!s.set).map(s=>s.day.toLowerCase()).join(", "),db=ss.filter(s=>s.set).map(s=>s.day.toLowerCase()).join(", ");
  $("#menu").innerHTML=`<h2>Rinkinys A</h2><p class="small">Gamini: ${da}</p>`+shown.map(sl=>card(sl,0)).join("")+(db?`<h2>Rinkinys B</h2><p class="small">Gamini: ${db}. Pusryčiai ir užkandžiai – tokie patys.</p>`+shown.filter(sl=>sl.k==="L"||sl.k==="D").map(sl=>card(sl,1)).join(""):"")}
 else $("#menu").innerHTML=shown.map(sl=>card(sl,0)).join("");
 $("#weekAI").hidden=!sample;
};
const DAYN=["Sekmadienis","Pirmadienis","Antradienis","Trečiadienis","Ketvirtadienis","Penktadienis","Šeštadienis"];
const sessions=()=>{const N=Math.min(7,Math.max(1,Math.round(num(st.prof.prep,4))));const out=[];for(let d=0,i=0;d<7;d+=N,i++)out.push({day:DAYN[d],n:Math.min(N,7-d),set:VAR()?i%2:0});return out};
const fq1=(q,u)=>!q||!u?"":u==="vnt"?(Math.ceil(q*2-0.1)/2+" vnt.").replace(".",","):q>=1000?fmtN(Math.round(q/100)/10)+(u==="g"?" kg":" l"):Math.max(5,Math.round(q/10)*10)+" "+u;
let sesIdx=0;let sdone=new Set(get("mp-steps",[]));
const altOf=(r,i)=>{const o=(ALT[r.id]||{})[i];if(!o)return null;if(o.gp&&!E("gp"))return o.gp;if(!E("ov")&&E("af")&&o.af)return o.af;if(!E("ov")&&!E("af")&&o.pan)return o.pan;if(o.bl&&!E("bl"))return o.bl;return null};
const stepsOf=r=>{const base=Array.isArray(r.steps)&&r.steps.length?r.steps:(r.prep||[]).map(x=>[x,0,0]);return base.map((s,i)=>altOf(r,i)||s)};
const altered=r=>!!ALT[r.id]&&Object.keys(ALT[r.id]).some(i=>altOf(r,+i));
const timeOf=r=>{const s=stepsOf(r),sa=s.filter(x=>!x[2]).reduce((t,x)=>t+(+x[1]||0),0),mw=Math.max(0,...s.filter(x=>x[2]).map(x=>+x[1]||0));const alt=altered(r);const A=!alt&&Number.isFinite(r.a)?r.a:sa,TT=!alt&&Number.isFinite(r.t)?r.t:sa+mw;return {a:A,t:Math.max(A,TT)}};
const fmtMin=m=>m>=60?`${Math.floor(m/60)} val.${m%60?" "+m%60+" min":""}`:`${m} min`;
const amt=(q,u)=>{if(!u)return "";if(u==="vnt")return String(Math.max(.5,Math.round(q*2)/2)).replace(".",",");if(q>=1000)return fmtN(Math.round(q/100)/10)+(u==="g"?" kg":" l");return (q<10?Math.max(1,Math.round(q)):Math.round(q/5)*5)+" "+u};
const fillStep=(txt,r,days,hh)=>{const n=Math.max(1,Math.ceil(days*hh));return String(txt).replace(/\{(p?)(\d+)\}|\{n\}/g,(m,p,i)=>{if(m==="{n}")return n;const g=r.ing[+i];if(!g)return "";return amt(p?g[1]:g[1]*days*hh,g[2])})};
const timeChip=r=>{const tm=timeOf(r);return tm.t?`<span class="tm">Aktyviai ${fmtMin(tm.a)} · Iš viso ${fmtMin(tm.t)}${r.note?" "+esc(r.note):""}</span>`:""};
const renderStore=()=>{const it=[];
 it.push(E("fz")?"Pagamintą maistą šaldytuve laikyk iki 3 dienų, ilgiau – šaldiklyje. Kiekvieną vakarą rytdienos dėžutes perkelk iš šaldiklio į šaldytuvą.":"Šaldiklio neturi – pagamintą maistą šaldytuve laikyk iki 3 dienų, todėl gaminti verta ne daugiau kaip 3 dienoms į priekį.");
 const rh=[];if(E("mw"))rh.push("mikrobangėje 2–3 min (dangtelį palik pravirą, įpusėjus pamaišyk)");if(E("hob"))rh.push("troškinius ir padažus – puode 5 min, mėsą su kruopomis – keptuvėje su šlakeliu vandens");if(E("ov"))rh.push("orkaitėje stiklinėje dėžutėje 180 °C, 15 min");if(E("af"))rh.push("airfryer 160 °C, 6–8 min (sausesniems patiekalams)");
 it.push(rh.length?"Šildymas: "+rh.join("; ")+".":"Šildyti nėra kuo – rinkis patiekalus, kuriuos skanu valgyti šaltus.");
 it.push("Pusryčius ir užkandžius ruošk ne daugiau kaip 3–4 dienoms.");
 $("#store").innerHTML=`<ul>${it.map(x=>`<li>${x}</li>`).join("")}</ul>`};
const renderCook=()=>{renderStore();const ss=sessions(),hh=HH(),N=num(st.prof.prep,4);if(sesIdx>=ss.length)sesIdx=0;const S=ss[sesIdx],n=Math.max(1,Math.ceil(S.n*hh));
 const recs=[];SLOTS.forEach(sl=>{const r=vrec(sl.k,S.set),ex=recs.find(x=>x.r.id===r.id);if(ex){ex.m++;ex.lab=slotLabel(SLOTS.find(x=>x.k==="L")||sl)}else recs.push({sl,r,m:1,lab:slotLabel(sl)})});const tms=recs.map(x=>timeOf(x.r));
 const est=tms.reduce((s,t)=>s+t.a,0)+Math.max(0,...tms.map(t=>t.t-t.a));
 const order=recs.map((x,i)=>({...x,tm:tms[i]})).filter(x=>x.tm.t>5).sort((a,b)=>(b.tm.t-b.tm.a)-(a.tm.t-a.tm.a));
 const pc=E("gp")?recs.filter(x=>stepsOf(x.r).some(s=>/greitpuod/i.test(s[0]))).length:0;
 const chips=`<div class="ses">${ss.map((s,i)=>`<button class="chip${i===sesIdx?" on":""}" data-ses="${i}">${s.day} · ${s.n} d.${VAR()?(s.set?" · B":" · A"):""}</button>`).join("")}</div>`;
 const plan=`<div class="card"><span class="t">${S.day} – gaminimo eiga</span><h3>~${fmtMin(est)} virtuvėje, ${n} porc. kiekvieno patiekalo</h3>
  <ol>${order.map((x,i)=>`<li><b>${esc(x.r.n)}</b> – ${i===0?"pradėk nuo jo, ilgiausiai gaminasi":"ruošk, kol gaminasi ankstesni"} (${fmtMin(x.tm.t)})</li>`).join("")}${recs.filter(x=>timeOf(x.r).t<=5).map(x=>`<li><b>${esc(x.r.n)}</b> – greitai, pabaigoje arba valgymo dieną</li>`).join("")}</ol>
  ${pc>1?`<p class="small">Greitpuodis vienas, o jo reikia ${pc} receptams – ryžius ar grikius virk puode, kad nereikėtų laukti.</p>`:""}
  ${N>3?(E("fz")?`<p class="small">Pirmų 3 dienų porcijas laikyk šaldytuve, likusias – šaldiklyje.</p>`:`<p class="warn">Šaldiklio neturi – gaminti daugiau nei 3 dienoms į priekį nesaugu. Profilyje pasirink 2–3 dienas.</p>`):""}
  ${(st.prof.people||[]).length?`<p class="small">Namie valgo ${1+st.prof.people.length} asm. – kiekiai ×${hh.toFixed(2).replace(".",",")} tavo porcijos.</p>`:""}
  <button class="btn" id="clrSteps">Išvalyti atliktų žingsnių žymes</button></div>`;
 $("#cook").innerHTML=chips+plan+recs.map(({sl,r,m,lab},ri)=>{const stp=stepsOf(r);const hm=hh*m,nn=Math.max(1,Math.ceil(S.n*hm));
  const ing=(r.ing||[]).map(([nm,q,u,cc])=>`<li>${q>0&&u?`<b>${amt(q*S.n*hm,u)}${u==="vnt"?" vnt.":""}</b> `:""}${esc(nm)}${q>0?`<span class="rawt">${rawTag(nm,cc)}</span>`:""}${q>0&&u==="g"&&rawTag(nm,cc)?`<span class="rawt"> → ~${amt(q*S.n*hm*YLD(nm),u)} ${rawTag(nm,cc)===" (žalia)"?"pagaminta":"išvirtų"}, po ~${amt(q*S.n*hm*YLD(nm)/nn,u)} į dėžutę</span>`:""}</li>`).join("");
  return `<details class="rcp"${ri===0?" open":""}><summary><span class="t">${lab}${m>1?" · dvigubas kiekis":""}</span><b class="rn">${esc(r.n)}</b>${timeChip(r)}</summary>
   <div class="grp">Produktai – ${nn} porc. · svoriai prieš gaminant (mėsa žalia, kruopos sausos); šalia – kiek gausis pagaminto</div><ul class="ingl">${ing}</ul>
   <div class="grp">Žingsniai – bakstelk, kai atlikai</div>
   <ol class="steps">${stp.map((s,i)=>{const key=sesIdx+"|"+r.id+"|"+i,dn=sdone.has(key),m=+s[1]||0;return `<li class="${dn?"dn":""}" data-sk="${esc(key)}"><div class="stx">${esc(fillStep(s[0],r,S.n,hm))}</div>${m?`<div class="smeta"><span>${s[2]?"laukti ":""}${fmtMin(m)}</span>${s[2]&&m>=2?`<button class="chip" data-tmr="${m}" data-lbl="${esc(r.n)}: ${i+1} žingsnis">Laikmatis ${m} min</button>`:""}</div>`:""}</li>`}).join("")}</ol>
   ${kids()&&r.ing.some(i=>/išrūgų/i.test(i[0]))?`<p class="warn">Vaiko porcijai baltymų miltelių nedėk – pakeisk pienu ar jogurtu.</p>`:""}</details>`}).join("");
};
const shopList=()=>{
 const map=new Map();
 const hh=HH(),tr=num(st.prof.trips,1)||1;sessions().forEach(S=>SLOTS.forEach(sl=>(vrec(sl.k,S.set).ing||[]).forEach(([n,q,u,c])=>{const key=n.toLowerCase()+"|"+u;const o=map.get(key)||{n,u,c:CATS.includes(c)?c:O,q:0};o.q+=(+q||0)*S.n*hh/tr;map.set(key,o)})));
 const fq=o=>{if(!o.q||!o.u)return "";if(o.u==="vnt")return Math.ceil(o.q-0.05)+" vnt.";const big=o.u==="g"?"kg":"l";const r=Math.max(50,Math.ceil(o.q/50)*50);if(r>=1000)return fmtN(Math.ceil(o.q/100)/10)+" "+big;return r+" "+o.u};
 return CATS.map(c=>[c,[...map.values()].filter(o=>o.c===c).map(o=>[o.n,fq(o),o.q,o.u])]).filter(g=>g[1].length);
};
const term=a=>a.split(",")[0].replace(/\(.*?\)/g,"").replace(/\d+([.,]\d+)?\s*%/g,"").replace(/\s+/g," ").trim().toLowerCase();
const fmtE=v=>v.toFixed(2).replace(".",",")+" €";
const packs=(q,u,P)=>{const sz=P[2],pu=P[3];if(!q)return 1;if(pu==="vnt"){if(u==="vnt")return Math.max(1,Math.ceil((q-0.05)/sz));return 1}if(u==="vnt")return 1;return Math.max(1,Math.ceil(q/sz-0.05))};
const per100=P=>`${P[4]} kcal · B ${fmtN(P[8])} g · A ${fmtN(P[6])} g (cukrų ${fmtN(P[7])} g) · R ${fmtN(P[5])} g · druska ${fmtN(P[9])} g`;
const unitP=P=>P[3]==="vnt"?(P[2]>1?fmtE(P[10]/P[2])+"/vnt.":fmtE(P[10])+"/vnt."):fmtE(P[10]/P[2]*1000)+(P[3]==="ml"?"/l":"/kg");
const protE=P=>P[8]>0&&P[3]!=="vnt"?fmtE(P[10]/P[2]*100/P[8]*100)+" už 100 g baltymų":"";
const renderShop=()=>{
 let n=0,tot=0,cost=0,cn=0;
 $("#shop").innerHTML=shopList().map(([g,items])=>`<div class="grp">${g}</div>`+items.map(([a,q,qq,uu])=>{const id=a+"|"+q,on=shop.includes(id);tot++;if(on)n++;const pk=pkey(a),PR=pk&&PROD[pk];const best=PR&&prodSel(pk),si=PR?PR.it.indexOf(best):-1;
  let pline="";if(best){const np=packs(qq,uu,best),c=np*best[10];cost+=c;cn++;
   pline=`<details class="pc"><summary><span class="pbest">Rimi${si>0?" (tavo pasirinkta)":""}: <b>${esc(best[1])}</b></span><span class="pmeta">${np>1?np+" × ":""}${fmtE(best[10])}${np>1?" = "+fmtE(c):""} · ${unitP(best)}</span></summary>
    <p class="pwhy">${esc(PR.w)}</p>
    ${PR.it.map((P,i)=>`<div class="pi${i===0?" top":""}${i===si?" sel":""}"><a href="https://www.rimi.lt/e-parduotuve/lt/produktai/p/${P[0]}" target="_blank" rel="noopener">${i===0?"Geriausia: ":""}${esc(P[1])}</a><div class="small">100 g: ${per100(P)}</div><div class="small">${fmtE(P[10])} · ${unitP(P)}${PR.m==="prot"&&protE(P)?" · "+protE(P):""}</div>${i===si?`<span class="small selt">✓ Naudojama skaičiuojant makro ir kainą</span>`:`<button type="button" class="chip" data-psel="${pk}" data-pi="${i}">Rinktis šią</button>`}${i===0&&si>0?` <span class="small">rekomenduojama</span>`:""}</div>`).join("")}
   </details>`}
  const qs=encodeURIComponent(PR?PR.q:term(a));
  return `<div class="srow"><label class="chk${on?" on":""}"><input type="checkbox" data-id="${esc(id)}"${on?" checked":""}><span>${esc(a)}${(()=>{const t=rawTag(a,g);return t?`<span class="rawt">${t}</span>`:""})()}</span><em>${esc(q)}</em></label>${pline}<div class="links"><a class="lk" href="https://www.rimi.lt/e-parduotuve/lt/paieska?query=${qs}" target="_blank" rel="noopener">Rimi</a><a class="lk" href="https://barbora.lt/paieska?q=${qs}" target="_blank" rel="noopener">Maxima</a></div></div>`}).join("")).join("");
 const tr=num(st.prof.trips,1),pp=1+(st.prof.people||[]).length;$("#shopProg").textContent=(n?`Krepšelyje ${n} iš ${tot} · `:"")+(tr>1?"Vienam apsipirkimui (pusė savaitės)":"Visai savaitei")+(pp>1?`, ${pp} asm.`:"");
 $("#shopCost").innerHTML=cn?`<span class="t">Apytikslė krepšelio kaina Rimi</span><b>~${fmtE(cost)}</b><span class="small">${cn} prekės su rekomenduojamomis prekėmis · be prieskonių, vaisių ir nesurastų prekių · kainos ${PDATE}</span>`:"";
};
const renderAll=()=>{SLOTS=ALLSLOTS.filter(s=>(MEALSETS[st.prof.meals]||MEALSETS[5]).includes(s.k));T=calc();if(VAR()){st.menuB=st.menuB||{};["L","D"].forEach(k=>{if(!st.menuB[k]||st.menuB[k]===st.menu[k])st.menuB[k]=pickOther(k,1)})}FAC=[0,1].map(s=>{let Pp=0,Kp=0,Po=0,Ko=0;SLOTS.forEach(x=>{const sm=splitMac(rec(x.k,s));Pp+=sm.P.p;Kp+=kc(sm.P);Po+=sm.O.p;Ko+=kc(sm.O)});
 const uni=Math.min(1.8,Math.max(.6,(Kp+Ko)?T.kcal/(Kp+Ko):1));const det=Pp*Ko-Po*Kp;
 if(Math.abs(det)<1e-6||!Pp)return {p:uni,o:uni};let fp=(T.p*Ko-Po*T.kcal)/det,fo=(Pp*T.kcal-T.p*Kp)/det;
 if(!(fp>0)||!(fo>0)){return {p:uni,o:uni}}fp=Math.min(2.5,Math.max(.4,fp));fo=Math.min(2.5,Math.max(.4,fo));return {p:fp,o:fo}});fac=(FAC[0].p+FAC[0].o)/2;renderProf();renderDay();renderMenu();renderCook();renderShop();renderReport()};

const pickOther=(k,s=0)=>{const cur=s?(st.menuB||{})[k]:st.menu[k],oth=VAR()&&(k==="L"||k==="D")?(s?st.menu[k]:(st.menuB||{})[k]):null;const others=all().filter(r=>r.s===k&&r.id!==cur&&r.id!==oth);const ok=others.filter(r=>!viol(r).length);const pool=ok.length?ok:others;return pool.length?pool[Math.floor(Math.random()*pool.length)].id:cur};

const RULES=()=>{const p=st.prof,pf=PF(),rx=RX.filter(([k])=>p.rx[k]||pf.rx[k]).map(x=>x[1].toLowerCase());
 return `Žmogus: ${p.sex==="f"?"moteris":"vyras"}, ${p.age} m., ${p.w} kg, ${p.h} cm; ${p.str}× jėgos (${p.strMin} min) ir ${p.end}× ištvermės (${p.endMin} min) treniruotės per savaitę. Tikslas: ${GNAME[p.goal]||p.goal}. Dienos tikslas apie ${T.kcal} kcal: B ${T.p} g, A ${T.c} g, R ${T.f} g, skaidulų ${T.fib} g. ${(p.people||[]).length?`Namuose valgo dar: ${p.people.map(x=>`${x.who||(num(x.age,30)<18?"vaikas":"suaugęs")} (${x.sex==="f"?"mot.":"vyr."}, ${x.age} m.)`).join(", ")} – tie patys patiekalai turi tikti visiems${kids()?", ir vaikams (ne aštrūs, paprasti skoniai; baltymų miltelius vaikų porcijose galima praleisti)":""}.`:"Gyvena vienas."} Valgo ${SLOTS.length} kartus per dieną. Gamina kas ${p.prep} d. į priekį, apsiperka ${p.trips} k. per savaitę.
Griežti apribojimai: ${rx.length?rx.join("; "):"nėra"}. Žuvis: ${({all:"valgo",ts:"tik tunas ir lašiša",none:"nevalgo jokios žuvies"})[p.fish]||"valgo"}. ALERGENAI – JOKIU BŪDU nenaudok: ${[...new Set([...Object.keys(p.alg||{}).filter(k=>p.alg[k]),...Object.keys(PF().alg)])].map(k=>ALG.find(x=>x[0]===k)[1]).join(", ")||"nėra"}. Žmogaus žodžiais apie maistą: „${String(p.dislike||"").slice(0,200)||"–"}“ (gali būti su klaidomis – suprask prasmę ir laikykis). Gaminimo būdas: ${MODEN[p.mode]||MODEN.std}. Virtuvėje TURI: ${EQ.filter(([k])=>E(k)).map(x=>x[1]).join(", ")||"tik paprastus indus"}. NETURI (nenaudok receptuose): ${EQ.filter(([k])=>!E(k)).map(x=>x[1]).join(", ")||"–"}.${E("fz")?"":" Šaldiklio nėra – maistas turi išsilaikyti šaldytuve."} Receptai paprasti, mažai indų, tinka laikyti dėžutėse 3 dienas šaldytuve arba šaldiklyje.
Naudok tik produktus, kuriuos realiai galima nupirkti Rimi (rimi.lt) ir Maxima (barbora.lt) parduotuvėse Lietuvoje, ir vadink juos aiškiais lietuviškais pavadinimais, kaip parduotuvėse (pvz., „Liesa varškė“, „Liesas tirštas jogurtas (Skyr)“, „Viščiukų krūtinėlių filė“, „Grikių kruopos“). Užsienietišką žodį rašyk tik skliaustuose po lietuviško paaiškinimo. Pakuočių dydžius rinkis įprastus.
Makro skaičiuok realiai pagal žalių/sausų produktų svorį.`};
const tSlot=s=>{const B=baseT();return {p:Math.round(s.t.p*T.p/B.p),c:Math.round(s.t.c*T.c/B.c),f:Math.round(s.t.f*T.f/B.f)}};
const norm=r=>{if(!r)return r;const F=FAC[0];return {...r,p:Math.round(r.p/F.p),c:Math.round(r.c/F.o),f:Math.round(r.f/F.o),ing:r.ing.map(([n,q,u,c])=>[n,q/fOf(F,n),u,c])}};
const SCHEMA=`Kiekvienas receptas – JSON objektas: {"n":"pavadinimas lietuviškai","d":"viena eilutė su pagrindiniais kiekiais vienai porcijai","p":baltymai_g_sveikas,"c":angliavandeniai_g_sveikas,"f":riebalai_g_sveikas,"ing":[["produktas",kiekis_vienai_porcijai_skaičius,"g"|"ml"|"vnt"|"","kategorija"]],"a":aktyvaus_darbo_minutės,"t":bendra_trukmė_minutėmis,"steps":[["aiškus žingsnis: ką, kiek, kokia temperatūra, kiek laiko, kaip atpažinti, kad gatava",minutės,1_jei_tai_laukimas_kai_galima_daryti_kitką_arba_0]]}. Žingsnių 4–8, rašyk taip, kad pradedantysis nepasimestų: įkaitinimas, pjaustymas, kepimas/virimas su laiku ir temperatūra, ką daryti laukiant, sudėjimas į dėžutes ir laikymas. Žingsnių tekste kiekius rašyk tik vietos žymėmis: {0}, {1}… – ingrediento pagal indeksą „ing“ sąraše kiekis visam gaminimui; {p0}, {p1}… – kiekis vienai porcijai; {n} – porcijų skaičius. Pvz.: "Supjaustyk {0} vištienos krūtinėlės kubeliais". Vienetų po žyme nerašyk – jie įrašomi automatiškai (vnt. žymei rašyk, pvz., „kiaušinius ({1} vnt.)“). Kategorija – tiksliai viena iš: ${CATS.join(", ")}. Prieskoniams kiekis 0 ir vienetas "".`;
const valid=(o,k)=>o&&typeof o.n==="string"&&o.n.trim()&&[o.p,o.c,o.f].every(x=>Number.isFinite(+x))&&Array.isArray(o.ing)&&o.ing.length&&(Array.isArray(o.steps)||Array.isArray(o.prep))
 ?{id:"ai"+Date.now().toString(36)+Math.random().toString(36).slice(2,6),s:k,ai:true,n:String(o.n).slice(0,80),d:String(o.d||"").slice(0,200),p:Math.round(+o.p),c:Math.round(+o.c),f:Math.round(+o.f),
   ing:o.ing.filter(i=>Array.isArray(i)&&i[0]).slice(0,14).map(i=>[String(i[0]).slice(0,50),Math.max(0,+i[1]||0),["g","ml","vnt",""].includes(i[2])?i[2]:"",CATS.includes(i[3])?i[3]:O]),
   steps:(Array.isArray(o.steps)?o.steps:o.prep).slice(0,10).map(s=>Array.isArray(s)?[String(s[0]).slice(0,400),Math.max(0,Math.min(240,Math.round(+s[1]||0))),+s[2]?1:0]:[String(s).slice(0,400),0,0]),
   a:Number.isFinite(+o.a)?Math.round(+o.a):undefined,t:Number.isFinite(+o.t)?Math.round(+o.t):undefined}:null;
const addCustom=r=>{st.custom=[r,...st.custom.filter(x=>x.s!==r.s||x.n!==r.n)].slice(0,60)};
const avoid=k=>all().filter(r=>r.s===k).map(r=>r.n).join("; ");
const status=(t,err)=>{const e=$("#weekStatus");e.textContent=t;e.className="status"+(err?" err":"")};
const errText=e=>e&&e.code==="daily_limit"?`Šiandienos Claude užklausų limitas${e.limit?" ("+e.limit+")":""} išnaudotas – rytoj vėl galėsi.`:e&&e.code==="rate_limited"?"Per daug užklausų – pabandyk po minutės.":e&&e.code==="offline"?"Nėra interneto ryšio – Claude veikia tik prisijungus prie interneto.":e&&e.code==="auth"?"Prisijungimas pasibaigė – atsijunk ir prisijunk iš naujo.":e&&e.code==="not_configured"?"Serveris dar nesukonfigūruotas (Vercel nustatymuose trūksta raktų).":"Nepavyko sukurti recepto. Pabandyk dar kartą.";

const aiOne=async(k,s=0)=>{const key=k+"|"+s;
 if(!sample||busy.has(key))return;const sl=SLOTS.find(x=>x.k===k),cur=rec(k,s);
 busy.add(key);renderMenu();status("");
 try{
  const prompt=`${RULES()}\n\nSukurk VIENĄ naują receptą valgiui „${sl.n}“ (${sl.w||"dienos metu"}). Vienos porcijos makro apie B ${tSlot(sl).p} g, A ${tSlot(sl).c} g, R ${tSlot(sl).f} g (±10 %). ${st.prof.mode==="one"&&k==="L"?"Šis patiekalas bus valgomas ir pietums, ir vakarienei – turi tikti abiem. ":""}Jam nepatiko „${cur.n}“. Nekartok šių: ${avoid(k)}.\n${SCHEMA}\nGrąžink tik tą JSON objektą.`;
  const r=norm(valid(await sample.json(prompt,{modelTier:"default",cache:false}),k));
  if(!r)throw {code:"bad"};
  addCustom(r);if(s){st.menuB=st.menuB||{};st.menuB[k]=r.id}else st.menu[k]=r.id;save();shop=[];set("mp-shop2",shop);
 }catch(e){status(errText(e),true)}
 busy.delete(key);renderAll();
};
const aiWeek=async()=>{
 if(!sample||busy.size)return;SLOTS.forEach(s=>{busy.add(s.k+"|0");busy.add(s.k+"|1")});$("#weekAI").disabled=true;$("#weekRand").disabled=true;renderMenu();status("Claude kuria visos savaitės meniu…");
 try{
  const prompt=`${RULES()}\n\nSukurk naujos savaitės meniu: po VIENĄ receptą kiekvienam valgiui, kuris valgomas kasdien visą savaitę. Dienos suma apie B ${T.p} g, A ${T.c} g, R ${T.f} g.\n${SLOTS.map(s=>`${s.k} – ${s.n}: apie B ${tSlot(s).p}, A ${tSlot(s).c}, R ${tSlot(s).f}. Nekartok: ${avoid(s.k)}`).join("\n")}\n${st.prof.mode==="one"?"Pietūs (L) bus valgomi ir vakarienei – sukurk L, o D grąžink tokį patį kaip L.":"Pietūs ir vakarienė turi skirtis pagrindiniu baltymu šaltiniu."}${VAR()?" Papildomai sukurk antrą pietų ir vakarienės rinkinį raktais L2 ir D2 – kitokius patiekalus kitam gaminimui.":""}\n${SCHEMA}\nGrąžink tik JSON objektą {${[...SLOTS.map(s=>s.k),...(VAR()?["L2","D2"]:[])].map(k=>`"${k}":{…}`).join(",")}}.`;
  const out=await sample.json(prompt,{modelTier:"default",cache:false});
  let n=0;SLOTS.forEach(s=>{const r=norm(valid(out&&out[s.k],s.k));if(r){addCustom(r);st.menu[s.k]=r.id;n++}});if(VAR()){st.menuB=st.menuB||{};["L","D"].forEach(k=>{const r=norm(valid(out&&out[k+"2"],k));if(r){addCustom(r);st.menuB[k]=r.id}})}
  if(!n)throw {code:"bad"};
  save();shop=[];set("mp-shop2",shop);
  status(n>=SLOTS.length?"Nauja savaitė paruošta. Pirkiniai atnaujinti.":`Pakeista ${n} iš ${SLOTS.length} valgių.`);
 }catch(e){status(errText(e),true)}
 busy.clear();$("#weekAI").disabled=false;$("#weekRand").disabled=false;renderAll();
};


$("#menu").addEventListener("click",e=>{const nx=e.target.closest("[data-next]"),ai=e.target.closest("[data-ai]");
 if(nx){const k=nx.dataset.next,s=+nx.dataset.set||0;if(s){st.menuB=st.menuB||{};st.menuB[k]=pickOther(k,1)}else st.menu[k]=pickOther(k);save();shop=[];set("mp-shop2",shop);status("");renderAll()}
 if(ai)aiOne(ai.dataset.ai,+ai.dataset.set||0)});
$("#weekRand").addEventListener("click",()=>{SLOTS.forEach(s=>{st.menu[s.k]=pickOther(s.k)});if(VAR()){st.menuB=st.menuB||{};["L","D"].forEach(k=>{st.menuB[k]=pickOther(k,1)})}save();shop=[];set("mp-shop2",shop);status("Nauja savaitė iš receptų bazės. Pirkiniai atnaujinti.");renderAll()});
$("#weekAI").addEventListener("click",aiWeek);
$("#shop").addEventListener("change",e=>{const id=e.target.dataset.id;if(!id)return;shop=e.target.checked?[...shop,id]:shop.filter(x=>x!==id);set("mp-shop2",shop);renderShop()});
$("#shop").addEventListener("click",e=>{const b=e.target.closest("[data-psel]");if(!b)return;e.preventDefault();st.psel=st.psel||{};st.psel[b.dataset.psel]=+b.dataset.pi;save();const open=b.closest("details");renderAll();const k=b.dataset.psel;setTimeout(()=>{const d=[...document.querySelectorAll("#shop details")].find(x=>x.querySelector(`[data-psel="${k}"]`)||x.querySelector(".sel"));},0)});
$("#resetShop").addEventListener("click",()=>{shop=[];set("mp-shop2",shop);renderShop()});

const FIELDS=["sex","age","h","w","move","str","strMin","end","endMin","goal","pace","pkg","dislike","meals","prep","trips","mode","fish","wmode","kcalMan"];
const renderPeople=()=>{$("#people").innerHTML=(st.prof.people||[]).map((x,i)=>`<div class="card" style="background:var(--bg)"><div class="row"><b>${esc(x.who||("Asmuo "+(i+2)))}</b><button type="button" class="btn" data-rm="${i}">Pašalinti</button></div><div class="g2">
 <label>Kas (nebūtina)<input type="text" data-pi="${i}" data-pf="who" value="${esc(x.who||"")}" placeholder="pvz., sūnus"></label>
 <label>Lytis<select data-pi="${i}" data-pf="sex"><option value="m"${x.sex!=="f"?" selected":""}>Vyr.</option><option value="f"${x.sex==="f"?" selected":""}>Mot.</option></select></label>
 <label>Amžius<input type="number" inputmode="numeric" min="1" max="99" data-pi="${i}" data-pf="age" value="${esc(x.age)}"></label>
 <label>Aktyvumas<select data-pi="${i}" data-pf="act">${Object.entries(ACTN).map(([k,l])=>`<option value="${k}"${(x.act||"mid")===k?" selected":""}>${l}</option>`).join("")}</select></label>
 ${num(x.age,30)>=18?`<label>Svoris, kg (nebūtina)<input type="number" inputmode="decimal" data-pi="${i}" data-pf="w" value="${esc(x.w||"")}"></label>`:""}
 </div><p class="small">~${pKcal(x).toLocaleString("lt-LT")} kcal per dieną · ${(pKcal(x)/T.kcal).toFixed(2).replace(".",",")} tavo porcijos</p></div>`).join("")};
$("#addP").addEventListener("click",()=>{st.prof.people=[...(st.prof.people||[]),{who:"",sex:"f",age:8,act:"mid",w:""}];save();renderPeople();renderAll()});
$("#people").addEventListener("click",e=>{const b=e.target.closest("[data-rm]");if(!b)return;st.prof.people.splice(+b.dataset.rm,1);save();renderPeople();renderAll()});
$("#people").addEventListener("change",e=>{if(e.target.dataset.pf==="age")renderPeople()});
$("#eqOpts").innerHTML=EQ.map(([k,l])=>`<label><input type="checkbox" data-eq="${k}"> ${l}</label>`).join("");
$("#algOpts").innerHTML=ALG.map(([k,l])=>`<button type="button" class="wt" data-alg="${k}">${l}</button>`).join("");
const showRec=(el,txt)=>{const a=recog(parseFree(txt));el.innerHTML=a.length?"Atpažinta: "+a.map(x=>`<span class="rchip">${esc(x)}</span>`).join(" "):""};
$("#rxOpts").innerHTML=RX.map(([k,l])=>`<label><input type="checkbox" data-rx="${k}"> ${l}</label>`).join("");
const fillForm=()=>{FIELDS.forEach(f=>{const el=$("#f-"+f);if(el)el.value=st.prof[f]??""});document.querySelectorAll("[data-rx]").forEach(c=>{c.checked=!!st.prof.rx[c.dataset.rx]});document.querySelectorAll("[data-eq]").forEach(c=>{c.checked=!!st.prof.eq[c.dataset.eq]});document.querySelectorAll("[data-alg]").forEach(c=>c.classList.toggle("on",!!st.prof.alg[c.dataset.alg]));showRec($("#freeRec"),st.prof.dislike)};
const renderPkg=()=>{const r=protRec(st.prof),el=$("#f-pkg");if(document.activeElement!==el)el.value=r.eff;
 $("#pkgHint").innerHTML=`${esc(r.why)}${r.boost?" + 10 % atsargai raumenims":""} → rekomenduojama <b>${fmtN(r.rec)} g/kg</b>${r.adj?` (skaičiuojama nuo koreguoto ${fmtN(r.wt)} kg svorio, nes KMI > 30)`:""}.${st.prof.pkgManual&&r.eff!==r.rec?` <button type="button" class="chip" id="pkgReset">Naudoti rekomenduojamą</button>`:""}`};
const renderTips=()=>{const g=st.prof.goal,f=n=>fmtN(Math.round(n*10)/10),wk=T.wk;let H,L;
 if(g==="gain"){H="Svoris ir perteklius";const lo=Math.max(.1,wk*.6),hi=Math.max(.3,wk*1.25);L=[[`+${f(lo)}–${f(hi)} kg per savaitę:`,"palik kaip yra – tai daugiausia raumenys."],["2–3 savaites nekyla:","+150–200 kcal (porcija kruopų, riešutai ar aliejus)."],[`Daugiau nei +${f(Math.max(.5,hi+.2))} kg per savaitę:`,"−150 kcal – per greitas priaugimas daugiausia riebalai."]]}
 else if(g==="maintain"){H="Svorio išlaikymas";L=[["±0,3 kg per savaitę:","palik kaip yra – tai įprasti svyravimai."],["2–3 savaites kyla:","−150 kcal."],["2–3 savaites krenta:","+150 kcal."]]}
 else{H=g==="recomp"?"Svoris ir rekompozicija":"Svoris ir deficitas";const lo=Math.max(.1,-wk*.6),hi=Math.max(.3,-wk*1.25);L=[[`−${f(lo)}–${f(hi)} kg per savaitę:`,"palik kaip yra."],[g==="recomp"?"2–3 savaites nekrenta ir juosmuo nemažėja:":"2–3 savaites nekrenta:","−150–200 kcal (riešutai, dalis kruopų)."],[`Daugiau nei −${f(Math.max(1,num(st.prof.w,80)*.01))} kg per savaitę ar išsekimas:`,"+200–300 kcal angliavandenių."]];if(g==="recomp")L.push(["Svoris stovi, bet juosmuo mažėja ir jėga auga:","viskas gerai – tai ir yra rekompozicija."])}
 $("#tipH").textContent=H;$("#tipList").innerHTML=`<ul>${L.map(([a,b])=>`<li><b>${a}</b> ${b}</li>`).join("")}</ul><p class="small">Ataskaitos skirtukas tai stebi automatiškai ir pasakys, ką keisti.</p>`};
const renderProf=()=>{renderPkg();renderTips();$("#paceL").hidden=!(st.prof.goal==="lose"||st.prof.goal==="gain");
 const w=T.wk,wt=Math.abs(w)<.05?"svoris turėtų išlikti panašus":`${w<0?"−":"+"}${fmtN(Math.round(Math.abs(w)*10)/10)} kg per savaitę`;
 $("#profRes").innerHTML=`<span class="t">Tavo dienos tikslas</span><div class="figs"><div class="big"><b>${T.kcal.toLocaleString("lt-LT")} kcal</b>${GNAME[st.prof.goal]||""} · tikėtina ${wt}</div><div><b>${T.p} g</b>baltymų</div><div><b>${T.c} g</b>angliavandenių</div><div><b>${T.f} g</b>riebalų</div><div><b>${T.fib} g</b>skaidulų</div><div><b>${T.bmr.toLocaleString("lt-LT")}</b>bazinė apykaita, kcal</div><div><b>${T.tdee.toLocaleString("lt-LT")}</b>sunaudoji per dieną, kcal</div></div>${T.man?`<p class="small">Naudojamas tavo nustatytas tikslas. Programa pagal profilį siūlytų ${T.kcalRec.toLocaleString("lt-LT")} kcal.</p>`:""}${T.adapt?`<p class="small">Energijos poreikis apskaičiuotas pagal tavo žurnalą ir svorį (formulė rodytų ${T.tdeeF.toLocaleString("lt-LT")} kcal). <button type="button" class="chip" id="adReset">Grąžinti formulę</button></p>`:""}${(()=>{const w=warnList(T,st.prof);return w.length?`<div class="warnbox"><b>Atkreipk dėmesį</b><ul>${w.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><p class="small">Tai tik įspėjimas – sprendi tu. Planas skaičiuojamas taip, kaip nustatei.</p></div>`:""})()}`};
let pt;$("#pf").addEventListener("input",e=>{const id=(e.target.id||"").replace("f-","");
 if(e.target.dataset.pi!==undefined){const x=st.prof.people[+e.target.dataset.pi];if(x)x[e.target.dataset.pf]=e.target.value;save();clearTimeout(pt);pt=setTimeout(()=>{renderAll();document.querySelectorAll("#people .small").forEach((s,i)=>{const p=st.prof.people[i];if(p)s.textContent=`~${pKcal(p).toLocaleString("lt-LT")} kcal per dieną · ${(pKcal(p)/T.kcal).toFixed(2).replace(".",",")} tavo porcijos`})},150);return}
 if(e.target.dataset.eq)st.prof.eq[e.target.dataset.eq]=e.target.checked?1:0;else if(e.target.dataset.rx)st.prof.rx[e.target.dataset.rx]=e.target.checked?1:0;else if(FIELDS.includes(id))st.prof[id]=e.target.value;
 if(id==="pkg")st.prof.pkgManual=1;
 save();clearTimeout(pt);pt=setTimeout(renderAll,150)});
$("#pf").addEventListener("submit",e=>e.preventDefault());
$("#pf").addEventListener("click",e=>{if(e.target.closest("#pkgReset")){st.prof.pkgManual=0;save();renderAll()}});
$("#profRes").addEventListener("click",e=>{if(e.target.closest("#adReset")){st.prof.tdeeAdj=0;save();renderAll()}});
$("#algOpts").addEventListener("click",e=>{const b=e.target.closest("[data-alg]");if(!b)return;const k=b.dataset.alg;st.prof.alg[k]=st.prof.alg[k]?0:1;b.classList.toggle("on");save();renderAll()});
$("#f-dislike").addEventListener("input",e=>showRec($("#freeRec"),e.target.value));
fillForm();renderPeople();
let timers=[],actx=null,tick=null;
const beep=()=>{try{if(!actx)return;for(let i=0;i<3;i++){const o=actx.createOscillator(),g=actx.createGain();o.frequency.value=880;o.connect(g);g.connect(actx.destination);const t0=actx.currentTime+i*.45;g.gain.setValueAtTime(.0001,t0);g.gain.exponentialRampToValueAtTime(.3,t0+.02);g.gain.exponentialRampToValueAtTime(.0001,t0+.35);o.start(t0);o.stop(t0+.4)}}catch(e){}try{navigator.vibrate&&navigator.vibrate([300,150,300])}catch(e){}};
const drawT=()=>{const now=Date.now();$("#timers").innerHTML=timers.map(t=>{const left=Math.max(0,Math.round((t.end-now)/1000));const mm=Math.floor(left/60),ss=String(left%60).padStart(2,"0");return `<div class="tmr${left===0?" end":""}"><b>${left===0?"Baigta":mm+":"+ss}</b><span>${esc(t.lbl)}</span><button data-tx="${t.id}">${left===0?"Gerai":"Stabdyti"}</button></div>`}).join("");
 timers.forEach(t=>{if(!t.rang&&t.end<=now){t.rang=1;beep()}});if(!timers.length&&tick){clearInterval(tick);tick=null}};
const addTimer=(m,lbl)=>{try{if(!actx){const AC=window.AudioContext||window.webkitAudioContext;if(AC)actx=new AC()}actx&&actx.resume&&actx.resume()}catch(e){}
 timers.push({id:Date.now()+Math.random(),lbl,end:Date.now()+m*60000});if(!tick)tick=setInterval(drawT,1000);drawT()};
$("#timers").addEventListener("click",e=>{const b=e.target.closest("[data-tx]");if(!b)return;timers=timers.filter(t=>String(t.id)!==b.dataset.tx);drawT()});
$("#cook").addEventListener("click",e=>{
 const tm=e.target.closest("[data-tmr]");if(tm){e.stopPropagation();addTimer(+tm.dataset.tmr,tm.dataset.lbl);return}
 const sb=e.target.closest("[data-ses]");if(sb){sesIdx=+sb.dataset.ses;renderCook();return}
 if(e.target.closest("#clrSteps")){sdone=new Set();set("mp-steps",[]);renderCook();return}
 const li=e.target.closest("[data-sk]");if(li){const k=li.dataset.sk;sdone.has(k)?sdone.delete(k):sdone.add(k);set("mp-steps",[...sdone]);li.classList.toggle("dn")}});
/* ---------- DIENOS ŽURNALAS ---------- */
const pad=n=>String(n).padStart(2,"0");
const ds=d=>d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate());
const pd=s=>{const [y,m,d]=s.split("-").map(Number);return new Date(y,m-1,d)};
const addD=(s,n)=>{const d=pd(s);d.setDate(d.getDate()+n);return ds(d)};
const TODAY=()=>ds(new Date());
const WD=["S","Pr","An","Tr","Kt","Pn","Š"];
const WDL=["sekmadienis","pirmadienis","antradienis","trečiadienis","ketvirtadienis","penktadienis","šeštadienis"];
const MON=["sausio","vasario","kovo","balandžio","gegužės","birželio","liepos","rugpjūčio","rugsėjo","spalio","lapkričio","gruodžio"];
const nice=s=>{const d=pd(s);return `${MON[d.getMonth()]} ${d.getDate()} d., ${WDL[d.getDay()]}`};
let LOG=get("mp-log",{});if(!LOG||typeof LOG!=="object")LOG={};
let cur=TODAY(),openOther=null;
const ent=(d,make)=>{if(!LOG[d]&&make)LOG[d]={m:{},x:[],u:0};return LOG[d]};
const ST={eat:"Valgiau",half:"Pusę",skip:"Praleidau",other:"Kita"};
const mealVal=(e)=>{if(!e)return {p:0,c:0,f:0,k:0};if(e.s==="eat")return {p:e.p,c:e.c,f:e.f,k:kc(e)};if(e.s==="half")return {p:e.p/2,c:e.c/2,f:e.f/2,k:kc(e)/2};if(e.s==="other")return {p:+e.op||0,c:+e.oc||0,f:+e.of||0,k:+e.ok||0};return {p:0,c:0,f:0,k:0}};
const dayTot=d=>{const E0=LOG[d];if(!E0)return null;const t={p:0,c:0,f:0,k:0,xk:0};Object.values(E0.m||{}).forEach(e=>{const v=mealVal(e);t.p+=v.p;t.c+=v.c;t.f+=v.f;t.k+=v.k});(E0.x||[]).forEach(x=>{t.k+=+x.k||0;t.p+=+x.p||0;t.xk+=+x.k||0});
 t.logged=Object.keys(E0.m||{}).length>0||(E0.x||[]).length>0;return t};
const touch=d=>{const e=ent(d,true);e.u=Date.now();set("mp-log",LOG);syncLog(d)};

const renderDay=()=>{const t0=TODAY();if(cur>t0)cur=t0;
 $("#dTitle").textContent=cur===t0?"Šiandien":cur===addD(t0,-1)?"Vakar":nice(cur).split(",")[0];
 $("#dSub").textContent=nice(cur);$("#dNext").disabled=cur>=t0;
 const E0=LOG[cur]||{m:{},x:[]};
 const ds0=setOf(cur);$("#meals").innerHTML=SLOTS.map(sl=>{const r=vrec(sl.k,ds0),e=(E0.m||{})[sl.k],s=e?.s||"";
  const shown=e&&e.s!=="other"&&e.n&&e.n!==r.n?{...r,n:e.n,p:e.p,c:e.c,f:e.f}:r;
  return `<div class="meal2 st-${s||"none"}"><span class="t">${sl.n}${sl.w?" · "+sl.w:""}${s?` · <b>${ST[s]}</b>`:""}</span><h3>${esc(shown.n)}</h3>${s==="other"?`<p>${esc(e.on||"Kitas maistas")} – ${Math.round(e.ok||0)} kcal, B ${Math.round(e.op||0)} g</p>`:`<p>${esc(r.d)}</p>${macs(shown)}`}
  <div class="seg">${Object.entries(ST).map(([k,l])=>`<button class="sb${s===k?" on":""}" data-ms="${sl.k}" data-v="${k}">${l}</button>`).join("")}</div>
  ${openOther===sl.k?`<form class="oform form" data-of="${sl.k}"><label>Ką valgei?<input type="text" name="on" value="${esc(e?.on||"")}" placeholder="pvz., picos 2 gabalai"></label><div class="g3"><label>kcal<input type="number" inputmode="numeric" name="ok" value="${esc(e?.ok??"")}"></label><label>Baltymai, g<input type="number" inputmode="numeric" name="op" value="${esc(e?.op??"")}"></label><label>Angliav., g<input type="number" inputmode="numeric" name="oc" value="${esc(e?.oc??"")}"></label></div><button class="btn pri">Išsaugoti</button></form>`:""}</div>`}).join("");
 $("#extras").innerHTML=(E0.x||[]).length?`<ul class="xl">${E0.x.map((x,i)=>`<li><span>${esc(x.n||"Užkandis")}</span><em>${Math.round(+x.k||0)} kcal · B ${Math.round(+x.p||0)} g</em><button class="chip" data-xd="${i}" aria-label="Ištrinti">Ištrinti</button></li>`).join("")}</ul>`:`<p class="small">Nieko papildomo – puiku.</p>`;
 const t=dayTot(cur)||{p:0,c:0,f:0,k:0};
 const tot=sum(SLOTS.map(x=>vrec(x.k)));
 $("#kcal").textContent=Math.round(t.k).toLocaleString("lt-LT");
 const DT=dayT(cur),dt=(LOG[cur]||{}).dt||"";
 $("#dType").innerHTML=Object.entries(DTYPES).map(([k,[l]])=>`<button type="button" class="chip${dt===k?" on":""}" data-dt="${k}">${l}</button>`).join("");
 $("#dTip").textContent=dt?(DTYPES[dt][1]?`Šiai dienai ${DTYPES[dt][1]>0?"+":"−"}${Math.abs(DTYPES[dt][1])} kcal (angliavandeniais). `:"")+DTYPES[dt][2]:"Pažymėk dienos tipą – tikslas prisitaikys.";
 $("#kcalLbl").textContent=`Suvalgyta iš ~${DT.kcal.toLocaleString("lt-LT")} kcal`;
 $("#bars").innerHTML=bars({p:Math.round(t.p),c:Math.round(t.c),f:Math.round(t.f)},DT);
 const marked=Object.keys(E0.m||{}).length;$("#dStat").textContent=marked<SLOTS.length?`Pažymėta ${marked} iš ${SLOTS.length} valgymų.`:"Visi valgymai pažymėti.";
 const w=E0.w;const el=$("#dW");if(document.activeElement!==el)el.value=w??"";
 const prevW=Object.keys(LOG).filter(d=>d<cur&&LOG[d].w).sort().pop();
 $("#wHint").textContent=w&&prevW?`${w-LOG[prevW].w>=0?"+":"−"}${fmtN(Math.abs(Math.round((w-LOG[prevW].w)*10)/10))} kg nuo ${nice(prevW).split(",")[0]}`:prevW?`Paskutinį kartą: ${fmtN(LOG[prevW].w)} kg (${nice(prevW).split(",")[0]})`:"Svėrkis ryte, po tualeto, prieš valgį.";
};
$("#dType").addEventListener("click",e=>{const b=e.target.closest("[data-dt]");if(!b)return;const E0=ent(cur,true);E0.dt=E0.dt===b.dataset.dt?"":b.dataset.dt;touch(cur);renderDay()});
$("#dPrev").addEventListener("click",()=>{cur=addD(cur,-1);openOther=null;renderDay()});
$("#dNext").addEventListener("click",()=>{cur=addD(cur,1);openOther=null;renderDay()});
$("#meals").addEventListener("click",e=>{const b=e.target.closest("[data-ms]");if(!b)return;const k=b.dataset.ms,v=b.dataset.v,E0=ent(cur,true),old=E0.m[k];
 if(v==="other"){openOther=openOther===k?null:k;renderDay();return}
 if(old&&old.s===v){delete E0.m[k]}else{const r=vrec(k,setOf(cur));E0.m[k]={s:v,n:r.n,p:r.p,c:r.c,f:r.f}}
 openOther=null;touch(cur);renderDay();renderReport()});
$("#meals").addEventListener("submit",e=>{e.preventDefault();const f=e.target.closest("[data-of]");if(!f)return;const k=f.dataset.of,fd=new FormData(f),E0=ent(cur,true);
 E0.m[k]={s:"other",on:String(fd.get("on")||"").slice(0,80),ok:num(fd.get("ok"),0),op:num(fd.get("op"),0),oc:num(fd.get("oc"),0),of:0};openOther=null;touch(cur);renderDay();renderReport()});
$("#exForm").addEventListener("submit",e=>{e.preventDefault();const fd=new FormData(e.target),k=num(fd.get("k"),0);if(!k&&!String(fd.get("n")||"").trim())return;
 const E0=ent(cur,true);E0.x=[...(E0.x||[]),{n:String(fd.get("n")||"").slice(0,60),k,p:num(fd.get("p"),0)}];e.target.reset();touch(cur);renderDay();renderReport()});
$("#extras").addEventListener("click",e=>{const b=e.target.closest("[data-xd]");if(!b)return;const E0=ent(cur,true);E0.x.splice(+b.dataset.xd,1);touch(cur);renderDay();renderReport()});
let wt;$("#dW").addEventListener("input",e=>{clearTimeout(wt);wt=setTimeout(()=>{const v=num(e.target.value,NaN),E0=ent(cur,true);if(Number.isFinite(v)&&v>30&&v<300)E0.w=Math.round(v*10)/10;else delete E0.w;touch(cur);renderDay();renderReport()},700)});

/* ---------- ATASKAITA ---------- */
let per="week";
const periodDays=()=>{const t0=TODAY(),d=pd(t0),dow=(d.getDay()+6)%7;const mon=addD(t0,-dow);
 if(per==="week")return {days:[...Array(7)].map((_,i)=>addD(mon,i)),label:"Ši savaitė"};
 if(per==="last")return {days:[...Array(7)].map((_,i)=>addD(mon,i-7)),label:"Praėjusi savaitė"};
 return {days:[...Array(28)].map((_,i)=>addD(t0,i-27)),label:"Paskutinės 4 savaitės"}};
const wSeries=(from,to)=>Object.keys(LOG).filter(d=>LOG[d].w&&d>=from&&d<=to).sort().map(d=>({d,w:LOG[d].w}));
const slope=pts=>{if(pts.length<2)return null;const x0=pd(pts[0].d).getTime();const xs=pts.map(p=>(pd(p.d).getTime()-x0)/864e5),ys=pts.map(p=>p.w);const n=xs.length,mx=xs.reduce((a,b)=>a+b)/n,my=ys.reduce((a,b)=>a+b)/n;let nu=0,de=0;xs.forEach((x,i)=>{nu+=(x-mx)*(ys[i]-my);de+=(x-mx)**2});return de?nu/de*7:null};
const kbars=(el,days,vals,target,unit)=>{const mx=Math.max(target*1.3,...vals.map(v=>v||0));const many=days.length>7;
 el.innerHTML=`<div class="ka">${days.map((d,i)=>{const v=vals[i];const hh=v==null?0:Math.max(2,v/mx*100);const cls=v==null?"na":v>target*1.1?"hi":v<target*.9?"lo":"ok";return `<div class="kc ${cls}" title="${d}: ${v==null?"nėra duomenų":Math.round(v)+" "+unit}">${v!=null&&!many?`<span class="kv" style="bottom:calc(${hh}% + 3px)">${Math.round(v)}</span>`:""}<div class="kbar" style="height:${hh}%"></div></div>`}).join("")}<div class="kt" style="bottom:${target/mx*100}%"><span>${Math.round(target)} ${unit}</span></div></div><div class="kds">${days.map(d=>`<span>${many?pd(d).getDate():WD[pd(d).getDay()]}</span>`).join("")}</div>`};
const drawW=()=>{const box=$("#rW");if(!box)return;const svg=box.querySelector("svg");const W=box.clientWidth,H=box.clientHeight;if(!W)return;
 const t0=TODAY(),from=addD(t0,-55),pts=wSeries(from,t0);
 if(pts.length<1){svg.innerHTML=`<text x="${W/2}" y="${H/2}" text-anchor="middle" fill="currentColor" opacity=".6" font-size="14">Įvesk svorį Dienos skirtuke</text>`;return}
 const x0=pd(from).getTime(),x1=pd(t0).getTime(),ws=pts.map(p=>p.w),lo=Math.min(...ws)-0.6,hi=Math.max(...ws)+0.6;const L=34,R=10,Tp=12,B=24;
 const X=d=>L+(pd(d).getTime()-x0)/(x1-x0||1)*(W-L-R),Y=w=>Tp+(hi-w)/(hi-lo||1)*(H-Tp-B);
 const avg=pts.map((p,i)=>{const win=pts.filter(q=>q.d<=p.d&&q.d>addD(p.d,-7));return {d:p.d,w:win.reduce((a,b)=>a+b.w,0)/win.length}});
 const ticks=[lo+0.6,(lo+hi)/2,hi-0.6].map(v=>Math.round(v*10)/10);
 svg.innerHTML=ticks.map(v=>`<line x1="${L}" x2="${W-R}" y1="${Y(v)}" y2="${Y(v)}" stroke="currentColor" opacity=".12"/><text x="${L-6}" y="${Y(v)+4}" text-anchor="end" font-size="11" fill="currentColor" opacity=".6">${fmtN(v)}</text>`).join("")
  +[0,4,8].map(k=>{const d=addD(from,k*7-0+ (k===8?-1:0));return `<text x="${X(addD(t0,-(8-k)*7))}" y="${H-6}" text-anchor="middle" font-size="11" fill="currentColor" opacity=".6">${pd(addD(t0,-(8-k)*7)).getMonth()+1}-${pd(addD(t0,-(8-k)*7)).getDate()}</text>`}).join("")
  +(avg.length>1?`<polyline fill="none" stroke="var(--acc)" stroke-width="2.5" stroke-linejoin="round" points="${avg.map(p=>X(p.d)+","+Y(p.w)).join(" ")}"/>`:"")
  +pts.map(p=>`<circle cx="${X(p.d)}" cy="${Y(p.w)}" r="3.5" fill="var(--card)" stroke="currentColor" stroke-width="1.5"/>`).join("")};
const roW=new ResizeObserver(drawW);
const reportData=()=>{const {days,label}=periodDays(),t0=TODAY(),past=days.filter(d=>d<=t0);
 const rows=past.map(d=>({d,t:dayTot(d),e:LOG[d]})).filter(x=>x.t&&x.t.logged);
 const n=rows.length,avg=k=>n?rows.reduce((a,r)=>a+r.t[k],0)/n:0;
 let planned=0,eat=0,half=0,skip=0,other=0;const skipBy={},otherBy={};
 rows.forEach(r=>SLOTS.forEach(sl=>{const e=r.e.m?.[sl.k];if(!e)return;planned++;if(e.s==="eat")eat++;else if(e.s==="half")half++;else if(e.s==="skip"){skip++;skipBy[sl.k]=(skipBy[sl.k]||0)+1}else if(e.s==="other"){other++;otherBy[sl.k]=(otherBy[sl.k]||0)+1}}));
 const xs=rows.flatMap(r=>r.e.x||[]);
 const wpts=wSeries(days[0],days[days.length-1]),wAll=wSeries(addD(t0,-41),t0);
 return {days,past,label,rows,n,kcal:avg("k"),p:avg("p"),c:avg("c"),f:avg("f"),xk:avg("xk"),planned,eat,half,skip,other,skipBy,otherBy,xs,wpts,rate:slope(wAll),adh:planned?(eat+half*.5)/planned:0}};
const insights=R=>{const out=[];const SN=Object.fromEntries(ALLSLOTS.map(s=>[s.k,s.n]));
 if(R.n<3){out.push(`Užpildyta tik ${R.n} d. – pažymėk valgymus bent 3–4 dienas, tada išvados bus patikimos.`)}
 if(R.n){const lowP=R.rows.filter(r=>r.t.p<T.p*.9).length;
  if(R.p<T.p*.9)out.push(`Baltymų vidutiniškai ${Math.round(R.p)} g per dieną – trūksta ~${Math.round(T.p-R.p)} g iki tikslo (${T.p} g). Trūko ${lowP} d. iš ${R.n}. Lengviausias papildymas: 250 g liesos varškės (+45 g) arba baltymų kokteilis (+25–30 g).`);
  else out.push(`Baltymai geri: vidutiniškai ${Math.round(R.p)} g per dieną (tikslas ${T.p} g).`);
  const dk=R.kcal-T.kcal;
  if(dk>T.kcal*.1)out.push(`Vidutiniškai suvalgai ~${Math.round(dk)} kcal per dieną daugiau nei tikslas (${Math.round(R.kcal)} vs ${T.kcal}).${R.xk>100?` Iš jų ~${Math.round(R.xk)} kcal – ne pagal planą.`:""}`);
  else if(dk<-T.kcal*.15)out.push(`Vidutiniškai suvalgai ~${Math.round(-dk)} kcal per mažai (${Math.round(R.kcal)} vs ${T.kcal}). ${st.prof.goal==="gain"?"Taip raumenys neaugs – nepraleisk valgymų arba padidink porcijas.":"Per didelis deficitas pablogina treniruotes ir atsigavimą – nepraleisk valgymų arba padidink porcijas."}`);
  else out.push(`Kalorijos arti tikslo: vidutiniškai ${Math.round(R.kcal)} kcal (tikslas ${T.kcal}).`);
  const top=Object.entries(R.skipBy).sort((a,b)=>b[1]-a[1])[0];
  if(top&&top[1]>=2)out.push(`Dažniausiai praleidi: ${SN[top[0]].toLowerCase()} (${top[1]} k.). Paruošk jį iš vakaro arba Meniu skirtuke pakeisk receptą į greitesnį.`);
  const ot=Object.entries(R.otherBy).sort((a,b)=>b[1]-a[1])[0];
  if(ot&&ot[1]>=2)out.push(`${SN[ot[0]]} ${ot[1]} k. pakeitei kitu maistu – gal šis receptas netinka? Išbandyk kitą Meniu skirtuke.`);
  if(R.xk>150){const names={};R.xs.forEach(x=>{const k=(x.n||"užkandis").toLowerCase();names[k]=(names[k]||0)+1});const tn=Object.entries(names).sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0]).join(", ");out.push(`Ne pagal planą vidutiniškai ~${Math.round(R.xk)} kcal per dieną${tn?` (dažniausiai: ${tn})`:""}. Jei tai alkis – padidink pagrindinių valgymų porcijas, o ne užkandžiauk.`)}
  const we=R.rows.filter(r=>[0,6].includes(pd(r.d).getDay())),wd=R.rows.filter(r=>![0,6].includes(pd(r.d).getDay()));
  if(we.length&&wd.length){const a=we.reduce((s,r)=>s+r.t.k,0)/we.length,b=wd.reduce((s,r)=>s+r.t.k,0)/wd.length;if(a-b>300)out.push(`Savaitgaliais suvalgai ~${Math.round(a-b)} kcal daugiau nei darbo dienomis. ${st.prof.goal==="lose"||st.prof.goal==="recomp"?"Tai gali „suvalgyti“ visos savaitės deficitą.":"Svarbu savaitės vidurkis – stenkis, kad dienos būtų panašesnės."}`)}
  if(R.adh>=.85)out.push(`Plano laikaisi ${Math.round(R.adh*100)} % – puikiai.`);
 }
 const g=st.prof.goal;
 if(R.rate==null)out.push("Svorio tendencijai reikia bent 2 svėrimų per kelias dienas – svėrkis 3–4 kartus per savaitę ryte.");
 else{const r=R.rate,rt=`${r<0?"−":"+"}${fmtN(Math.abs(Math.round(r*10)/10))} kg per savaitę`;
  if(g==="lose"||g==="recomp"){if(r>-0.1)out.push(`Svoris beveik nekinta (${rt}). Jei taip 2–3 savaites – sumažink 150–200 kcal: Profilyje pasirink greitesnį tempą arba atsisakyk riešutų / dalies kruopų.`);else if(r<-1)out.push(`Svoris krenta greitai (${rt}). Rizikuoji prarasti raumenų – pridėk 200–300 kcal angliavandenių.`);else out.push(`Svorio tempas geras: ${rt}.`)}
  else if(g==="gain"){if(r<0.1)out.push(`Svoris nekyla (${rt}) – pridėk 200 kcal per dieną.`);else if(r>0.5)out.push(`Svoris kyla greitai (${rt}) – dalis gali būti riebalai, sumažink 150 kcal.`);else out.push(`Svorio priaugimas tolygus: ${rt}.`)}
  else{if(Math.abs(r)>0.25)out.push(`Svoris keičiasi (${rt}), nors tikslas – išlaikyti. Pakoreguok ~${r>0?"−":"+"}150 kcal.`);else out.push(`Svoris stabilus (${rt}).`)}}
 return out};
const adaptive=()=>{const t0=TODAY(),days=[...Array(28)].map((_,i)=>addD(t0,-i-1));const full=days.filter(d=>LOG[d]&&Object.keys(LOG[d].m||{}).length>=Math.max(1,SLOTS.length-1));
 const pts=wSeries(addD(t0,-28),t0);const span=pts.length>1?(pd(pts[pts.length-1].d)-pd(pts[0].d))/864e5:0;
 if(full.length<10||pts.length<4||span<10)return {ok:false,msg:`Reikia bent 10 pilnai pažymėtų dienų ir 4 svėrimų per 10+ dienų (dabar: ${full.length} d., ${pts.length} svėr.). Tada programa apskaičiuos tavo tikrąjį poreikį – tiksliau nei formulė.`};
 const avg=Math.round(full.reduce((s,d)=>s+dayTot(d).k,0)/full.length),rate=slope(pts);const tdee=Math.round((avg-rate/7*7700)/10)*10;return {ok:tdee>800&&tdee<7000,tdee,avg,rate,n:full.length,wn:pts.length,msg:"Duomenys atrodo nepatikimi – patikrink, ar pažymėti visi valgymai."}};
const renderReport=()=>{if(!$("#rKpi"))return;const R=reportData();
 document.querySelectorAll("[data-per]").forEach(b=>b.classList.toggle("on",b.dataset.per===per));
 $("#rSub").textContent=`${R.label}: ${nice(R.days[0]).split(",")[0]} – ${nice(R.days[R.days.length-1]).split(",")[0]} · užpildyta ${R.n} iš ${R.past.length} d.`;
 const wl=R.wpts.length?R.wpts[R.wpts.length-1].w:null,wf=R.wpts.length>1?R.wpts[0].w:null;
 const kp=(l,v,s,cls="")=>`<div class="kp ${cls}"><b>${v}</b><span>${l}</span>${s?`<em>${s}</em>`:""}</div>`;
 $("#rKpi").innerHTML=kp("vid. kcal per dieną",R.n?Math.round(R.kcal).toLocaleString("lt-LT"):"–",R.n?`${R.kcal-T.kcal>=0?"+":"−"}${Math.abs(Math.round(R.kcal-T.kcal))} nuo tikslo`:"")
  +kp("vid. baltymai, g",R.n?Math.round(R.p):"–",R.n?`tikslas ${T.p} g`:"")
  +kp("plano laikymasis",R.planned?Math.round(R.adh*100)+" %":"–",R.planned?`praleista ${R.skip}, kita ${R.other}`:"")
  +kp("svoris, kg",wl?fmtN(wl):"–",wf!=null?`${wl-wf>=0?"+":"−"}${fmtN(Math.abs(Math.round((wl-wf)*10)/10))} per laikotarpį`:R.rate!=null?`${R.rate<0?"−":"+"}${fmtN(Math.abs(Math.round(R.rate*10)/10))} kg/sav.`:"");
 const tk=R.days.map(d=>{const t=d<=TODAY()?dayTot(d):null;return t&&t.logged?t.k:null}),tp=R.days.map(d=>{const t=d<=TODAY()?dayTot(d):null;return t&&t.logged?t.p:null});
 kbars($("#rKcal"),R.days,tk,T.kcal,"kcal");kbars($("#rProt"),R.days,tp,T.p,"g");
 $("#rSlots").innerHTML=SLOTS.map(sl=>{let e=0,h=0,s=0,o=0;R.rows.forEach(r=>{const x=r.e.m?.[sl.k];if(!x)return;x.s==="eat"?e++:x.s==="half"?h++:x.s==="skip"?s++:o++});const tot=R.n||1;
  return `<div class="sr"><span>${sl.n}</span><div class="stk">${[["eat",e],["half",h],["other",o],["skip",s]].map(([k,v])=>v?`<i class="${k}" style="width:${v/tot*100}%" title="${ST[k]}: ${v}"></i>`:"").join("")}</div><em>${e}/${R.n}</em></div>`}).join("")+`<p class="small lg"><i class="eat"></i>Valgiau <i class="half"></i>Pusę <i class="other"></i>Kita <i class="skip"></i>Praleidau</p>`;
 $("#rIns").innerHTML=insights(R).map(x=>`<li>${esc(x)}</li>`).join("");
 const AD=adaptive();$("#rAdapt").innerHTML=`<h3>Tavo tikrasis energijos poreikis</h3>${AD.ok?`<div class="kp"><b>~${AD.tdee.toLocaleString("lt-LT")} kcal</b><span>per dieną, pagal ${AD.n} pilnai pažymėtas dienas ir ${AD.wn} svėrimus</span></div><p class="small">Formulė rodo ${T.tdeeF.toLocaleString("lt-LT")} kcal. Vidutiniškai suvalgai ${AD.avg.toLocaleString("lt-LT")} kcal, o svoris keičiasi ${AD.rate<0?"−":"+"}${fmtN(Math.abs(Math.round(AD.rate*100)/100))} kg/sav.</p>${Math.abs(AD.tdee-T.tdee)>100?`<button type="button" class="btn pri" id="adApply">Taikyti: perskaičiuoti planą pagal ~${AD.tdee.toLocaleString("lt-LT")} kcal</button>`:`<p class="small">Planas jau atitinka tavo duomenis.</p>`}`:`<p class="small">${esc(AD.msg)}</p>`}`;
 $("#rAI").hidden=!sample;$("#rAInote").hidden=!!sample;
 drawW()};
$("#rAdapt").addEventListener("click",e=>{if(e.target.closest("#adApply")){const AD=adaptive();if(AD.ok){st.prof.tdeeAdj=AD.tdee;save();renderAll();$("#rStatus").textContent="Planas perskaičiuotas pagal tavo tikrąjį poreikį. Grąžinti formulę gali Profilyje."}}});
document.querySelectorAll("[data-per]").forEach(b=>b.addEventListener("click",()=>{per=b.dataset.per;$("#rAIout").innerHTML="";renderReport()}));
$("#rCsv").addEventListener("click",async()=>{const rows=[["data","kcal","baltymai_g","angliav_g","riebalai_g","svoris_kg","praleista","kita","papildomai_kcal"]];
 Object.keys(LOG).sort().forEach(d=>{const t=dayTot(d),e=LOG[d];if(!t)return;const m=Object.values(e.m||{});rows.push([d,Math.round(t.k),Math.round(t.p),Math.round(t.c),Math.round(t.f),e.w??"",m.filter(x=>x.s==="skip").length,m.filter(x=>x.s==="other").length,Math.round(t.xk)])});
 const csv=rows.map(r=>r.join(",")).join("\n");try{await navigator.clipboard.writeText(csv);$("#rStatus").textContent=`Nukopijuota ${rows.length-1} d. – įklijuok į Excel ar Google Sheets.`}catch(e){$("#rStatus").textContent="Nepavyko nukopijuoti – naršyklė neleidžia."}});
$("#rAI").addEventListener("click",async()=>{if(!sample)return;const R=reportData();if(!R.n){$("#rAIout").innerHTML=`<p class="small">Pirma pažymėk bent kelias dienas.</p>`;return}
 const b=$("#rAI");b.disabled=true;b.textContent="Claude analizuoja…";
 const SN=Object.fromEntries(ALLSLOTS.map(s=>[s.k,s.n]));
 const lines=R.rows.map(r=>{const m=r.e.m||{};return `${r.d} (${WDL[pd(r.d).getDay()]}): ${Math.round(r.t.k)} kcal, B ${Math.round(r.t.p)} g, A ${Math.round(r.t.c)} g, R ${Math.round(r.t.f)} g; praleista: ${Object.entries(m).filter(([,x])=>x.s==="skip").map(([k])=>SN[k]).join(", ")||"nieko"}; kita: ${Object.entries(m).filter(([,x])=>x.s==="other").map(([k,x])=>SN[k]+" – "+(x.on||"?")).join(", ")||"–"}; papildomai: ${(r.e.x||[]).map(x=>`${x.n} ${x.k} kcal`).join(", ")||"–"}${r.e.w?`; svoris ${r.e.w} kg`:""}`}).join("\n");
 const prompt=`Tu – patyręs sporto mitybos specialistas. Išanalizuok žmogaus mitybos žurnalą ir duok konkrečių patarimų lietuviškai.
Profilis: ${st.prof.sex==="f"?"moteris":"vyras"}, ${st.prof.age} m., ${st.prof.h} cm, ${st.prof.w} kg; tikslas: ${GNAME[st.prof.goal]}; ${st.prof.str}× jėgos ir ${st.prof.end}× ištvermės treniruotės per savaitę. Dienos tikslas: ${T.kcal} kcal, B ${T.p} g, A ${T.c} g, R ${T.f} g.
Planuoti valgymai: ${SLOTS.map(s=>s.n+" – "+vrec(s.k).n).join("; ")}.
Svorio tendencija: ${R.rate==null?"nežinoma":(Math.round(R.rate*100)/100)+" kg per savaitę"}.
Laikotarpis: ${R.label}. Dienos:
${lines}
Atsakyk 4–6 punktais, kiekvienas eilutėje, prasidedančioje „- “. Pradėk nuo svarbiausio. Kiekviename punkte – konkretus skaičius iš duomenų ir konkretus veiksmas (ką keisti, kiek). Paminėk ir tai, kas sekasi gerai. Be įžangų ir be medicininių diagnozių.`;
 try{const res=await sample(prompt,{modelTier:"default",cache:false});const items=String(res.text||"").split("\n").map(s=>s.trim()).filter(s=>s.startsWith("-")).map(s=>s.replace(/^-\s*/,"").replace(/\*\*/g,""));
  $("#rAIout").innerHTML=items.length?`<ul>${items.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`:`<p>${esc(res.text||"")}</p>`}
 catch(e){$("#rAIout").innerHTML=`<p class="warn">${esc(errText(e).replace("sukurti recepto","atlikti analizės"))}</p>`}
 b.disabled=false;b.textContent="Analizuoti su Claude"});

const views=["diena","meniu","gaminimas","pirkiniai","ataskaita","profilis"];
const show=v=>{if(!views.includes(v))v="diena";views.forEach(x=>{document.getElementById(x).hidden=x!==v});document.querySelectorAll(".tab").forEach(t=>t.setAttribute("aria-selected",t.dataset.v===v));window.scrollTo(0,0)};
document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>{location.hash=t.dataset.v;show(t.dataset.v)}));
addEventListener("hashchange",()=>show(location.hash.slice(1)));
/* ---------- PRADŽIOS VEDLYS ---------- */
const NDEF={...PDEF,mode:"",fish:"all",wmode:"",alg:{},age:"",h:"",w:"",sex:"",goal:"",pace:"mid",move:"",str:0,strMin:60,end:0,endMin:45,pkg:1.8,meals:"",prep:"",trips:"",people:[],rx:{pork:0,sea:0,pot:0,bread:0,veg:0},eq:{hob:1,ov:1,gp:0,af:0,mw:1,bl:0,sc:0,fz:1},dislike:""};
let W=null,ws=0;
const opt=(f,v,l,d)=>`<button class="wo${String(W[f])===String(v)?" on":""}" data-wf="${f}" data-wv="${v}"><b>${l}</b>${d?`<span>${d}</span>`:""}</button>`;
const tog=(g,k,l)=>`<button class="wt${W[g][k]?" on":""}" data-wg="${g}" data-wk="${k}">${l}</button>`;
const stp=(f,l,min,max,step,unit)=>`<div class="wst"><span>${l}</span><div><button class="ws" data-sf="${f}" data-sd="-${step}" data-min="${min}" data-max="${max}" aria-label="Mažiau">−</button><b>${W[f]}${unit||""}</b><button class="ws" data-sf="${f}" data-sd="${step}" data-min="${min}" data-max="${max}" aria-label="Daugiau">+</button></div></div>`;
const WSTEPS=[
 {t:"Sveiki!",d:"Atsakyk į kelis klausimus – programa sudarys tau kalorijas, meniu, porcijas, pirkinių sąrašą ir gaminimo planą. Užtruks apie 2 minutes.",ok:()=>true,b:()=>`<div class="wbig">7 klausimai · ~2 min</div>`,next:"Pradėti"},
 {t:"Kas tu?",d:"Reikia apskaičiuoti, kiek energijos sunaudoji.",ok:()=>W.sex&&num(W.age,0)>=14&&num(W.h,0)>=130&&num(W.w,0)>=35,b:()=>`<div class="wg2">${opt("sex","f","Moteris")}${opt("sex","m","Vyras")}</div>
  <div class="wg3"><label>Amžius<input type="number" inputmode="numeric" data-wi="age" value="${esc(W.age)}" placeholder="metai"></label><label>Ūgis<input type="number" inputmode="numeric" data-wi="h" value="${esc(W.h)}" placeholder="cm"></label><label>Svoris<input type="number" inputmode="decimal" step="0.1" data-wi="w" value="${esc(W.w)}" placeholder="kg"></label></div>`},
 {t:"Ko sieki?",d:"Pasirink vieną.",ok:()=>!!W.goal,b:()=>`<div class="wl">${opt("goal","lose","Numesti svorio","Mažinti riebalus")}${opt("goal","recomp","Sustiprėti ir sulieknėti","Lėtai mesti riebalus ir auginti raumenis")}${opt("goal","maintain","Išlaikyti svorį","Tiesiog sveikai ir sočiai maitintis")}${opt("goal","gain","Priaugti raumenų","Sportuoju ir noriu masės")}</div>
  ${W.goal==="lose"||W.goal==="gain"?`<p class="wq">Kokiu tempu?</p><div class="wg3">${opt("pace","slow","Lėtai")}${opt("pace","mid","Vidutiniškai")}${opt("pace","fast","Greitai")}</div>`:""}`},
 {t:"Kiek judi?",d:"Be treniruočių – kaip praeina įprasta diena.",ok:()=>!!W.move,b:()=>`<div class="wl">${opt("move","1.2","Daugiausia sėdžiu","Biuras, automobilis")}${opt("move","1.35","Sėdžiu, bet daug vaikštau","Pvz., vedžioju šunį")}${opt("move","1.5","Dirbu ant kojų","Parduotuvė, sandėlis")}${opt("move","1.65","Fizinis darbas","Statybos, ūkis")}</div>
  <p class="wq">Treniruotės per savaitę</p>${stp("str","Jėgos",0,14,1,"×")}${stp("end","Bėgimas, dviratis, plaukimas",0,14,1,"×")}${W.str||W.end?stp(W.end&&!W.str?"endMin":"strMin","Viena treniruotė trunka",15,240,15," min"):""}`},
 {t:"Kas valgo namuose?",d:"Kiekiai pirkiniams ir gaminimui bus visiems.",ok:()=>W.people.every(x=>num(x.age,0)>0),b:()=>`<div class="wpp"><div class="wme">Aš</div>${W.people.map((x,i)=>`<div class="wpr"><select data-pi2="${i}" data-pf2="sex"><option value="f"${x.sex==="f"?" selected":""}>Mot.</option><option value="m"${x.sex!=="f"?" selected":""}>Vyr.</option></select><input type="number" inputmode="numeric" data-pi2="${i}" data-pf2="age" value="${esc(x.age)}" placeholder="amžius"><button class="ws" data-prm="${i}" aria-label="Pašalinti">×</button></div>`).join("")}<button class="wadd" id="wAdd">+ Pridėti žmogų</button></div>`},
 {t:"Kaip nori gaminti?",d:"Pasirink, kas patogiausia. Nežinai – paspausk „Nežinau“, pasiūlysime.",ok:()=>W.meals&&W.prep&&W.trips&&W.mode&&W.wmode,b:()=>`<p class="wq">Kiek kartų per dieną valgai?</p><div class="wg3">${opt("meals",3,"3")}${opt("meals",4,"4")}${opt("meals",5,"5")}</div>
  <p class="wq">Kiek dienų gaminti į priekį?</p><div class="wg2">${opt("prep",1,"Kasdien")}${opt("prep",2,"2 dienoms")}${opt("prep",3,"3 dienoms")}${opt("prep",4,"4 dienoms")}${opt("prep",7,"Visai savaitei")}<button class="wo" data-wf="prep" data-wv="?"><b>Nežinau</b></button></div>${W.prepTip?`<p class="wtip">${W.prepTip}</p>`:""}
  <p class="wq">Kiek skirtingų patiekalų gaminti?</p><div class="wl">${opt("mode","one","Vieną","Tas pats pietums ir vakarienei – mažiausiai darbo")}${opt("mode","std","Du","Atskiri pietūs ir vakarienė")}${opt("mode","var","Vis kitus","Kiekvieną gaminimą – nauji pietūs ir vakarienė")}<button class="wo" data-wf="mode" data-wv="?"><b>Nežinau – pasiūlyk</b></button></div>${W.modeTip?`<p class="wtip">${W.modeTip}</p>`:""}
  <p class="wq">Kaip sveri porcijas?</p><div class="wl">${opt("wmode","raw","Prieš gaminant","Žalią mėsą, sausas kruopas – tiksliausia")}${opt("wmode","cooked","Pagamintą","Iškeptą mėsą, išvirtus ryžius – patogu dalinti į dėžutes")}<button class="wo" data-wf="wmode" data-wv="?"><b>Nežinau</b></button></div>${W.wTip?`<p class="wtip">${W.wTip}</p>`:""}
  <p class="wq">Kiek kartų per savaitę apsiperki?</p><div class="wg2">${opt("trips",1,"Kartą")}${opt("trips",2,"Du kartus")}</div>`},
 {t:"Ko nevalgai?",d:"Pažymėk, kas tinka. Jei viską valgai – tiesiog spausk „Toliau“.",ok:()=>true,b:()=>`<p class="wq">Žuvis</p><div class="wg3">${opt("fish","all","Valgau")}${opt("fish","ts","Tik tuną ir lašišą")}${opt("fish","none","Nevalgau")}</div>
  <p class="wq">Nevalgau</p><div class="wtg">${RX.map(([k,l])=>tog("rx",k,l)).join("")}</div>
  <p class="wq">Alergijos ir netoleravimas</p><div class="wtg">${ALG.map(([k,l])=>tog("alg",k,l)).join("")}</div>
  <label class="wlab">Ar parašyk laisvai – suprasiu ir su klaidomis<input type="text" data-wi="dislike" value="${esc(W.dislike)}" placeholder="pvz., nevalgau kiaulienos, alergija riešutams, nemėgstu grybų"></label><p class="small rec" id="wRec"></p>`},
 {t:"Ką turi virtuvėje?",d:"Receptai prisitaikys prie to, ką turi.",ok:()=>true,b:()=>`<div class="wtg">${EQ.map(([k,l])=>tog("eq",k,l.split(" (")[0])).join("")}</div>`},
 {t:"Tavo planas paruoštas",d:"Visada gali pakeisti Profilio skirtuke.",ok:()=>true,next:"Pradėti naudotis",b:()=>{const keep=st.prof;st.prof=W;const r=calc();st.prof=keep;return `<div class="wres"><b>${r.kcal.toLocaleString("lt-LT")}</b><span>kcal per dieną</span></div><div class="wg3 wm"><div><b>${r.p} g</b>baltymų (${fmtN(r.pr.eff)} g/kg)</div><div><b>${r.c} g</b>angliav.</div><div><b>${r.f} g</b>riebalų</div></div><p class="small">${W.people.length?`Gaminsi ${1+W.people.length} asmenims. `:""}${Math.abs(r.wk)>=.05?`Tikėtina: ${r.wk<0?"−":"+"}${fmtN(Math.round(Math.abs(r.wk)*10)/10)} kg per savaitę.`:"Svoris turėtų išlikti stabilus."}</p><p class="small">${esc(r.pr.why)}${r.pr.boost?" – pridėta +10 % atsargai, kad raumenys tikrai būtų išsaugoti ar augtų":""}.</p>${(()=>{const w=warnList(r,W);return w.length?`<div class="warnbox"><b>Atkreipk dėmesį</b><ul>${w.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><p class="small">Tik įspėjimas – viską galėsi pakeisti Profilyje.</p></div>`:""})()}`}}
];
const renderWiz=()=>{const S=WSTEPS[ws],n=WSTEPS.length-1;
 $("#wiz").innerHTML=`<div class="wtop">${ws?`<button class="wback" id="wBack" aria-label="Atgal">‹ Atgal</button>`:"<span></span>"}<span class="small">${ws&&ws<n?`${ws} iš ${n-1}`:""}</span></div>
 <div class="wbar"><i style="width:${ws/n*100}%"></i></div>
 <div class="wbody"><h1>${S.t}</h1><p class="sub">${S.d}</p>${S.b()}</div>
 <div class="wfoot"><button class="btn pri wide" id="wNext"${S.ok()?"":" disabled"}>${S.next||"Toliau"}</button></div>`};
const wizOk=()=>{const b=$("#wNext");if(b)b.disabled=!WSTEPS[ws].ok()};
const startWiz=(fresh)=>{W=JSON.parse(JSON.stringify(fresh?NDEF:st.prof));W.alg=W.alg||{};W.rx=W.rx||{};W.people=W.people||[];ws=fresh?0:1;document.body.classList.add("wizon");$("#wiz").hidden=false;renderWiz();window.scrollTo(0,0)};
const endWiz=()=>{delete W.prepTip;delete W.modeTip;delete W.wTip;
 W.people=W.people.map(x=>({who:"",act:"mid",w:"",...x}));st.prof={...W};st.onb=1;save();fillForm();renderPeople();shop=[];set("mp-shop2",shop);
 document.body.classList.remove("wizon");$("#wiz").hidden=true;renderAll();location.hash="meniu";show("meniu")};
$("#wiz").addEventListener("click",e=>{const t=e.target;
 const o=t.closest("[data-wf]");if(o&&o.dataset.wv==="?"&&o.dataset.wf==="wmode"){W.wmode="raw";W.wTip="Siūlome sverti prieš gaminant – taip tiksliausia. Gaminimo skirtuke vis tiek matysi, kiek pagamintos mėsos ar kruopų dėti į kiekvieną dėžutę.";renderWiz();return}
 if(o&&o.dataset.wv==="?"){if(o.dataset.wf==="prep"){W.prep=W.eq&&W.eq.fz?4:3;W.prepTip=`Siūlome ${W.prep} dienoms: gamini ${W.prep===4?"2 kartus":"2–3 kartus"} per savaitę, o maistas išlieka šviežias${W.prep===4?" (paskutinės dienos porcijas laikyk šaldiklyje)":""}.`}else{const sug=W.people.length?"std":num(W.prep,3)>=4?"var":num(W.prep,3)<=1?"var":"std";W.mode=sug;W.modeTip=sug==="var"?"Siūlome „Vis kitus“: gamini kelioms dienoms, todėl kas gaminimą bus nauji patiekalai – neatsibos.":"Siūlome „Du“: atskiri pietūs ir vakarienė – įvairu, bet gaminti nesudėtinga."+(W.people.length?" Tinka visai šeimai.":"")}renderWiz();return}
 if(o){W[o.dataset.wf]=o.dataset.wv;if(o.dataset.wf==="prep")W.prepTip="";if(o.dataset.wf==="mode")W.modeTip="";if(o.dataset.wf==="wmode")W.wTip="";if(o.dataset.wf==="goal")W.pkgManual=0;renderWiz();return}
 const g=t.closest("[data-wg]");if(g){W[g.dataset.wg][g.dataset.wk]=W[g.dataset.wg][g.dataset.wk]?0:1;g.classList.toggle("on");return}
 const s=t.closest("[data-sf]");if(s){const f=s.dataset.sf;W[f]=Math.min(+s.dataset.max,Math.max(+s.dataset.min,num(W[f],0)+(+s.dataset.sd)));if(f==="strMin")W.endMin=W.strMin;if(f==="endMin")W.strMin=W.endMin;renderWiz();return}
 const rm=t.closest("[data-prm]");if(rm){W.people.splice(+rm.dataset.prm,1);renderWiz();return}
 if(t.closest("#wAdd")){W.people.push({sex:"f",age:""});renderWiz();const ins=document.querySelectorAll('#wiz [data-pf2="age"]');ins[ins.length-1]?.focus();return}
 if(t.closest("#wBack")){ws=Math.max(0,ws-1);renderWiz();return}
 if(t.closest("#wNext")&&WSTEPS[ws].ok()){if(ws<WSTEPS.length-1){ws++;renderWiz();window.scrollTo(0,0)}else endWiz()}});
$("#wiz").addEventListener("input",e=>{const t=e.target;if(t.dataset.wi){W[t.dataset.wi]=t.value;if(t.dataset.wi==="dislike"&&$("#wRec"))showRec($("#wRec"),t.value);wizOk()}else if(t.dataset.pi2!==undefined){const x=W.people[+t.dataset.pi2];if(x)x[t.dataset.pf2]=t.value;wizOk()}});
$("#redoWiz").addEventListener("click",()=>startWiz(false));
const VER="2026-11-23c",NOTES="Mitybos planas – atnaujinimas 2026-11-23 (2)\n• Receptų kalorijos ir makro dabar skaičiuojami iš realios prekių sudėties (Rimi). Pirkiniuose gali „Rinktis šią“ kitą prekę – makro ir kaina persiskaičiuos (pvz., 18 % faršas vietoj liesos jautienos).\n• Porcijos derinamos dviem dydžiais: baltyminiai produktai ir kiti atskirai, todėl tiksliai pataikoma ir į kalorijas, ir į baltymus.\n• Savas kalorijų tikslas Profilyje – gali įrašyti bet kokį skaičių.\n• Įspėjimai vietoj apribojimų: per mažai kalorijų, per didelis deficitas, per greitas kritimas, per mažai riebalų ar angliavandenių ištvermei, per daug baltymų. Sprendžia vartotojas.\n• Tikrasis energijos poreikis: po 10+ pažymėtų dienų ir 4 svėrimų Ataskaita apskaičiuoja, kiek iš tikrųjų sudegini, ir pasiūlo perskaičiuoti planą (nebūtina).\n• Pataisyta: patarimai apie svorį Profilyje dabar priklauso nuo tikslo – priaugantiems nebekalbama apie deficitą.\n• Dienos tipas: Poilsis / Jėga / Ištvermė < 90 min / Ilga ištvermė 90+ min – dienos tikslas prisitaiko, ilgoms treniruotėms primenama, ką valgyti jų metu.\n\nMitybos planas – atnaujinimas 2026-11-23\n• Gaminimo būdas: 1 patiekalas pietums ir vakarienei, 2 atskiri, arba vis kiti kas gaminimą (rinkiniai A ir B). Yra „Nežinau – pasiūlyk“.\n• Gaminti į priekį: kasdien, 2, 3, 4 dienoms arba visai savaitei, su „Nežinau“.\n• Svoriai: rinkis, ar sveri žalią mėsą ir sausas kruopas, ar pagamintą maistą. Gaminimo skirtuke rodoma, kiek pagaminto dėti į dėžutę.\n• Visur grąžintos žymos „žalia“, „sausi“, „pagaminta“, „išvirti“.\n• Žuvis atskirai nuo jūros gėrybių: valgau / tik tunas ir lašiša / nevalgau.\n• 14 ES alergenų: pažymi savo, o receptų kortelėse matosi, kokių alergenų jie turi.\n• Laisvas tekstas su klaidomis, pvz., „kiaulenos nevalgau, alerija riesutams“ – programa supranta ir parodo, ką atpažino.\n• Baltymai pagal mokslines rekomendacijas (ISSN, Morton 2018, Helms 2014) ir sporto bendruomenių praktiką, +10 % raumenims auginti ar išsaugoti. Esant KMI > 30 skaičiuojama nuo koreguoto svorio.\n• Pradžios vedlys naujam vartotojui: vienas klausimas viename ekrane.\n• Pirkiniuose: rekomenduojamos Rimi prekės pagal sudėtį ir kainą, palyginimas, krepšelio kaina.\n• Dienos žurnalas (valgiau / pusę / praleidau / kita, svoris) ir ataskaita su išvadomis bei Claude analize.";
$("#updText").textContent=NOTES;
if(!NEWU&&get("mp-ver","")!==VER)$("#updBan").hidden=false;
$("#updHide").addEventListener("click",()=>{set("mp-ver",VER);$("#updBan").hidden=true});
$("#updShow").addEventListener("click",()=>{set("mp-ver",VER);$("#updBan").hidden=true;location.hash="profilis";show("profilis");$("#updBox").open=true;setTimeout(()=>$("#updBox").scrollIntoView({block:"start"}),50)});
$("#updCopy").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(NOTES);$("#updSt").textContent="Nukopijuota – gali įklijuoti draugams."}catch(e){$("#updSt").textContent="Naršyklė neleido kopijuoti – pažymėk tekstą ir nukopijuok rankomis."}});
if(NEWU)set("mp-ver",VER);
renderAll();show(location.hash.slice(1));
roW.observe($("#rW"));
/* ---------- SINCHRONIZAVIMAS IR PRISIJUNGIMAS (Supabase) ---------- */
const CFG=window.MP_CONFIG||{};
const sb=window.supabase&&CFG.SUPABASE_URL?window.supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}}):null;
let UID=null;
const note=t=>{const e=$("#syncNote");if(e)e.textContent=t};
// Neišsiųsti pakeitimai: "state" arba "d:YYYY-MM-DD". Išlieka ir be interneto, išsiunčiami vėliau.
let DIRTY=new Set(get("mp-dirty",[]));const saveDirty=()=>set("mp-dirty",[...DIRTY]);
let flushQ=Promise.resolve();const wq={};
const pushKey=async k=>{if(!(sb&&UID)||!DIRTY.has(k))return;let r={error:null};
 if(k==="state")r=await sb.from("user_state").upsert({user_id:UID,data:st,u:st.u||Date.now(),updated_at:new Date().toISOString()});
 else{const d=k.slice(2);if(LOG[d])r=await sb.from("day_logs").upsert({user_id:UID,day:d,data:LOG[d],u:LOG[d].u||Date.now(),updated_at:new Date().toISOString()})}
 if(r.error)throw r.error;DIRTY.delete(k);saveDirty()};
const enqueue=k=>{flushQ=flushQ.then(()=>pushKey(k)).catch(()=>note("Nepavyko išsaugoti debesyje – duomenys liko šiame įrenginyje ir bus išsiųsti, kai atsiras ryšys."));return flushQ};
const qPush=k=>{DIRTY.add(k);saveDirty();clearTimeout(wq[k]);wq[k]=setTimeout(()=>enqueue(k),1200)};
const flushAll=()=>{[...DIRTY].forEach(enqueue);return flushQ};
const syncState=()=>qPush("state");
const syncLog=d=>qPush("d:"+d);
addEventListener("online",()=>{if(UID)flushAll()});
const resetLocal=()=>{["mp2","mp-log","mp-shop2","mp-steps","mp-dirty"].forEach(k=>{try{localStorage.removeItem(k)}catch(e){}});
 st={menu:{...DEF},custom:[]};normState();LOG={};shop=[];sdone=new Set();DIRTY=new Set()};
const initSync=async()=>{if(!(sb&&UID))return;try{
  const {data:row,error:e1}=await sb.from("user_state").select("data,u").eq("user_id",UID).maybeSingle();if(e1)throw e1;
  if(row&&row.data&&row.data.prof&&(row.u||0)>(st.u||0)){st={...row.data,u:row.u};normState();set("mp2",st);DIRTY.delete("state");fillForm();renderPeople()}
  else if(st.onb&&(!row||(st.u||0)>(row.u||0)))DIRTY.add("state");
  const {data:days,error:e2}=await sb.from("day_logs").select("day,data,u").eq("user_id",UID).order("day",{ascending:false}).limit(5000);if(e2)throw e2;
  const remote={};(days||[]).forEach(r=>{remote[r.day]=r;if(r.data&&(!LOG[r.day]||(r.u||0)>(LOG[r.day].u||0)))LOG[r.day]=r.data});
  Object.keys(LOG).forEach(d=>{if(!remote[d]||(LOG[d].u||0)>(remote[d].u||0))DIRTY.add("d:"+d)});
  set("mp-log",LOG);saveDirty();flushAll();
  note("Duomenys saugomi tavo paskyroje – matysi juos ir kitame įrenginyje.");
 }catch(e){note("Nepavyko pasiekti debesies – kol kas duomenys saugomi šiame įrenginyje.")}};
/* Claude per serverį (/api/ai) */
const aiCall=async(prompt,json)=>{if(!navigator.onLine)throw {code:"offline"};const {data}=await sb.auth.getSession();const s=data&&data.session;if(!s)throw {code:"auth"};
 let r;try{r=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+s.access_token},body:JSON.stringify({prompt,json:!!json})})}catch(e){throw {code:"offline"}}
 let j={};try{j=await r.json()}catch(e){}if(!r.ok)throw {code:j.code||"bad",limit:j.limit};return j};
const setSample=()=>{if(!sb||!UID){sample=null}else{const s=async p=>({text:(await aiCall(p,false)).text||""});s.json=async p=>(await aiCall(p,true)).data;sample=s}
 $("#aiNote").textContent=sample?"„Kitas“ parenka kitą receptą iš bazės. Claude mygtukai kuria visiškai naujus receptus pagal tavo apribojimus.":"„Kitas“ parenka kitą receptą iš bazės."};
/* Prisijungimo ekranas */
let AM="in";
const authErr=e=>{const m=String(e&&e.message||"").toLowerCase();
 if(m.includes("invalid login"))return "Neteisingas el. paštas arba slaptažodis.";
 if(m.includes("already"))return "Toks el. paštas jau užregistruotas – prisijunk.";
 if(m.includes("password")&&(m.includes("least")||m.includes("short")||m.includes("weak")))return "Slaptažodis per trumpas arba per paprastas.";
 if(m.includes("not confirmed"))return "El. paštas dar nepatvirtintas – paspausk nuorodą laiške.";
 if(m.includes("rate limit")||m.includes("too many"))return "Per daug bandymų – pabandyk po kelių minučių.";
 if(m.includes("fetch")||m.includes("network"))return "Nėra interneto ryšio.";
 if(m.includes("provider")&&m.includes("not enabled"))return "Šis prisijungimo būdas dar neįjungtas.";
 return "Nepavyko: "+((e&&e.message)||"nežinoma klaida")};
const renderAuth=(msg="")=>{const up=AM==="up";
 $("#auth").innerHTML=`<div class="wtop"><span></span></div><div class="wbody"><h1>${up?"Sukurk paskyrą":"Prisijunk"}</h1><p class="sub">${up?"Duomenys bus saugomi tavo paskyroje – matysi juos telefone ir kompiuteryje.":"Mitybos planas: kalorijos, meniu, gaminimas, pirkiniai ir žurnalas."}</p>
 ${CFG.GOOGLE?`<button type="button" class="btn wide gbtn" id="gIn">Tęsti su Google</button><div class="or">arba el. paštu</div>`:""}
 <form id="aForm"><label class="wlab">El. paštas<input type="email" name="email" autocomplete="email" inputmode="email" required></label>
 <label class="wlab">Slaptažodis${up?" (bent 8 simboliai)":""}<input type="password" name="pw" autocomplete="${up?"new-password":"current-password"}" required${up?' minlength="8"':""}></label>
 <p class="aerr" id="aErr">${esc(msg)}</p><button class="btn pri wide" id="aGo">${up?"Sukurti paskyrą":"Prisijungti"}</button></form>
 <button type="button" class="alink" id="aSwitch">${up?"Jau turi paskyrą? Prisijunk":"Neturi paskyros? Sukurk"}</button></div>
 <p class="small" style="padding-bottom:24px">Tai ne medicininė konsultacija. Jei turi ligų ar vartoji vaistų, pasitark su gydytoju ar dietologu.</p>`};
const showAuth=(msg)=>{UID=null;sample=null;document.body.classList.remove("wizon");$("#wiz").hidden=true;document.body.classList.add("authon");$("#auth").hidden=false;renderAuth(msg)};
const hideAuth=()=>{document.body.classList.remove("authon");$("#auth").hidden=true};
$("#auth").addEventListener("click",async e=>{if(e.target.closest("#aSwitch")){AM=AM==="up"?"in":"up";renderAuth();return}
 if(e.target.closest("#gIn")){const {error}=await sb.auth.signInWithOAuth({provider:"google",options:{redirectTo:location.origin+"/"}});if(error)renderAuth(authErr(error))}});
$("#auth").addEventListener("submit",async e=>{e.preventDefault();const fd=new FormData(e.target),email=String(fd.get("email")||"").trim(),password=String(fd.get("pw")||"");
 const b=$("#aGo");b.disabled=true;b.textContent="Palauk…";let r;
 try{r=AM==="up"?await sb.auth.signUp({email,password}):await sb.auth.signInWithPassword({email,password})}catch(x){r={error:x}}
 if(r.error){renderAuth(authErr(r.error));return}
 if(AM==="up"&&!r.data.session){AM="in";renderAuth("Paskyra sukurta. Patvirtink el. laiške gautą nuorodą ir prisijunk.");return}});
const enterApp=()=>{hideAuth();renderAll();if(!st.onb)startWiz(true);else show(location.hash.slice(1))};
const onUser=async user=>{const prev=get("mp-uid",null);if(prev&&prev!==user.id)resetLocal();set("mp-uid",user.id);UID=user.id;
 $("#acctWho").textContent="Prisijungta: "+(user.email||"");hideAuth();await initSync();setSample();enterApp()};
if(sb)sb.auth.onAuthStateChange((ev,session)=>{setTimeout(()=>{
 if(session&&session.user){if(session.user.id!==UID)onUser(session.user);return}
 if(ev==="INITIAL_SESSION"&&!navigator.onLine&&get("mp-uid",null)){note("Be interneto – duomenys bus išsiųsti, kai atsiras ryšys.");enterApp();return}
 if(ev==="SIGNED_OUT"||ev==="INITIAL_SESSION")showAuth()},0)});
$("#logoutBtn").addEventListener("click",async()=>{if(DIRTY.size){await flushAll();if(DIRTY.size){$("#acctSt").textContent="Yra dar neišsiųstų duomenų – prisijunk prie interneto ir bandyk dar kartą.";return}}
 resetLocal();try{localStorage.removeItem("mp-uid")}catch(e){}await sb.auth.signOut().catch(()=>{});showAuth()});
/* Eksportas ir importas */
$("#expBtn").addEventListener("click",()=>{const o={app:"mityba",v:1,exported:new Date().toISOString(),state:st,log:LOG};
 const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(o,null,1)],{type:"application/json"}));a.download=`mityba-${TODAY()}.json`;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},2000);
 $("#acctSt").textContent="Failas paruoštas atsisiųsti."});
$("#impBtn").addEventListener("click",()=>$("#impFile").click());
$("#impFile").addEventListener("change",async e=>{const f=e.target.files&&e.target.files[0];e.target.value="";if(!f)return;let o;
 try{o=JSON.parse(await f.text())}catch(x){$("#acctSt").textContent="Netinkamas failas – tai ne JSON.";return}
 const S=o&&(o.state||o.st),L=o&&(o.log||o.LOG);if(!(S&&S.prof)&&!(L&&typeof L==="object")){$("#acctSt").textContent="Faile nerasta mitybos plano duomenų.";return}
 if(!confirm("Importuoti? Profilis ir meniu bus pakeisti failo duomenimis, o žurnalo dienos sujungtos su esamomis."))return;
 if(S&&S.prof){st={...S,onb:1};normState();st.u=Date.now();set("mp2",st);DIRTY.add("state")}
 let n=0;if(L&&typeof L==="object")Object.entries(L).forEach(([d,v])=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(d)||!v||typeof v!=="object")return;if(!LOG[d]||(v.u||0)>=(LOG[d].u||0)){LOG[d]=v;DIRTY.add("d:"+d);n++}});
 set("mp-log",LOG);saveDirty();fillForm();renderPeople();shop=[];set("mp-shop2",shop);renderAll();flushAll();
 $("#acctSt").textContent=`Importuota: ${S&&S.prof?"profilis ir meniu, ":""}${n} d. žurnalo.`});
if(!sb){note("Prisijungimo serveris nepasiekiamas – duomenys saugomi tik šiame įrenginyje.");setSample();enterApp()}
}
