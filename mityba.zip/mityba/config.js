// Vieši nustatymai (šiuos raktus rodyti galima – jie skirti naršyklei).
// Slaptieji raktai čia NIEKADA nerašomi – jie tik Vercel nustatymuose.
window.MP_CONFIG = {
  SUPABASE_URL: "https://quxtpkifohrggosllqyr.supabase.co",
  SUPABASE_KEY: "sb_publishable_UlKTy2d5XK8J0Qo_kKWFdQ_5mPVur4Q",
  GOOGLE: false // įjungsime, kai sukonfigūruosime Google prisijungimą
};
