-- Mitybos planas – duomenų bazės schema
-- Paleisti vieną kartą: Supabase → SQL Editor → New query → įklijuoti viską → Run.
-- Saugu paleisti ir pakartotinai (nieko neištrina).

-- 1. Vartotojo būsena: profilis, meniu, Claude receptai, pasirinktos prekės.
create table if not exists public.user_state (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  data       jsonb  not null default '{}'::jsonb,
  u          bigint not null default 0,            -- paskutinio pakeitimo laikas (ms), sinchronizavimui
  updated_at timestamptz not null default now()
);

-- 2. Dienos žurnalas: viena eilutė vienai dienai.
create table if not exists public.day_logs (
  user_id    uuid not null references auth.users(id) on delete cascade,
  day        date not null,
  data       jsonb  not null default '{}'::jsonb,  -- {m:{...}, x:[...], w, dt, u}
  u          bigint not null default 0,
  updated_at timestamptz not null default now(),
  primary key (user_id, day)
);

-- 3. Claude užklausų skaitiklis (dienos limitui).
create table if not exists public.ai_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  day     date not null default current_date,
  n       int  not null default 0,
  primary key (user_id, day)
);

-- Row Level Security: kiekvienas mato ir keičia tik savo duomenis.
alter table public.user_state enable row level security;
alter table public.day_logs   enable row level security;
alter table public.ai_usage   enable row level security;

drop policy if exists "own state" on public.user_state;
create policy "own state" on public.user_state
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "own logs" on public.day_logs;
create policy "own logs" on public.day_logs
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

-- ai_usage vartotojas gali tik skaityti; skaičiuoja tik serveris.
drop policy if exists "read own usage" on public.ai_usage;
create policy "read own usage" on public.ai_usage
  for select to authenticated
  using ((select auth.uid()) = user_id);

-- Limito funkcija: padidina skaitiklį ir grąžina true, jei dar neviršyta.
-- Kviečia tik serveris (service_role).
create or replace function public.ai_take(p_user uuid, p_limit int)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare v int;
begin
  insert into public.ai_usage(user_id, day, n) values (p_user, current_date, 1)
  on conflict (user_id, day) do update set n = public.ai_usage.n + 1
  returning n into v;
  if v > p_limit then
    update public.ai_usage set n = n - 1 where user_id = p_user and day = current_date;
    return false;
  end if;
  return true;
end $$;

revoke all on function public.ai_take(uuid, int) from public, anon, authenticated;
grant execute on function public.ai_take(uuid, int) to service_role;
