// Service worker: programėlė veikia ir be interneto.
// Pakeitus failus – padidink VERSION, kad telefonai gautų naują versiją.
const VERSION = "mityba-v1";
const SHELL = [
  "/", "/index.html", "/styles.css", "/app.js", "/config.js", "/vendor/supabase.js",
  "/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png", "/icons/apple-touch-icon.png"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // Serverio funkcijos ir Supabase – visada tik per internetą.
  if (url.pathname.startsWith("/api/") || url.hostname.endsWith("supabase.co")) return;

  // Šriftai – iš talpyklos, atnaujinami fone.
  if (url.hostname.includes("fonts.googleapis.com") || url.hostname.includes("fonts.gstatic.com")) {
    e.respondWith(
      caches.open(VERSION).then(async (c) => {
        const hit = await c.match(req);
        const net = fetch(req).then((r) => { if (r && (r.ok || r.type === "opaque")) c.put(req, r.clone()); return r; }).catch(() => hit);
        return hit || net;
      })
    );
    return;
  }

  if (url.origin !== location.origin) return;

  // Programėlės failai: pirmiausia internetas (kad gautum naujausią versiją), be ryšio – talpykla.
  e.respondWith(
    fetch(req)
      .then((r) => {
        if (r && r.ok) { const copy = r.clone(); caches.open(VERSION).then((c) => c.put(req, copy)); }
        return r;
      })
      .catch(async () => (await caches.match(req)) || (req.mode === "navigate" ? caches.match("/index.html") : Response.error()))
  );
});
